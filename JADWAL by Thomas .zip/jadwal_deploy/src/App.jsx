import { useState, useEffect, useRef } from "react";

// ═══════════════════════════════════════════════════════════
// DESIGN SYSTEM
// ═══════════════════════════════════════════════════════════
const C = {
  bg:"#07070d", card:"#0e0e18", cardHov:"#131320", border:"#1c1c2e", borderL:"#242438",
  gold:"#c9a84c", goldL:"#e8c878", goldD:"#7a6230", glow:"rgba(201,168,76,0.14)",
  text:"#eeeae0", sub:"#9090a8", dim:"#5a5a72",
  green:"#00c48c", greenD:"#003d2b", red:"#ff4560", redD:"#3d0010",
  blue:"#4a9eff", blueD:"#001a3d", orange:"#ffaa00", orangeD:"#3d2a00",
  purple:"#9b72ff", wa:"#25D366", waD:"#003d1a",
};

const css = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@600;700;800&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Noto+Kufi+Arabic:wght@400;600;700&display=swap');
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
  html{font-size:14px;scroll-behavior:smooth;}
  body{background:${C.bg};color:${C.text};font-family:'Plus Jakarta Sans',sans-serif;overflow-x:hidden;}
  ::-webkit-scrollbar{width:4px;} ::-webkit-scrollbar-thumb{background:${C.goldD};border-radius:2px;}
  input,select,textarea,button{font-family:inherit;}
  @keyframes fadeUp{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:translateY(0)}}
  @keyframes pop{0%{opacity:0;transform:scale(.88)}65%{transform:scale(1.04)}100%{opacity:1;transform:scale(1)}}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes glow{0%,100%{box-shadow:0 0 20px ${C.glow}}50%{box-shadow:0 0 44px rgba(201,168,76,.3)}}
  @keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}
  @keyframes ticker{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}
  @keyframes waPop{0%{opacity:0;transform:translateY(10px) scale(.94)}60%{transform:scale(1.03)}100%{opacity:1;transform:none}}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
  @keyframes scanLine{0%{top:5%}50%{top:85%}100%{top:5%}}
  .fu{animation:fadeUp .45s ease both;}
  .pop{animation:pop .4s cubic-bezier(.16,1,.3,1) both;}
  .float{animation:float 4s ease-in-out infinite;}
  .glow{animation:glow 3.5s ease infinite;}
  .pulse{animation:pulse 2s infinite;}
  .spinner{width:17px;height:17px;border:2.5px solid ${C.goldD};border-top-color:${C.gold};border-radius:50%;animation:spin .7s linear infinite;display:inline-block;flex-shrink:0;}
`;

// ═══════════════════════════════════════════════════════════
// TRANSLATIONS
// ═══════════════════════════════════════════════════════════
const TR = {
  en:{
    signIn:"Sign In", createAcc:"Create Account", signOut:"Sign Out",
    dashboard:"Dashboard", employees:"Employees", schedule:"AI Schedule",
    whatsapp:"WhatsApp", compliance:"Compliance", mohre:"MOHRE & Nafis",
    wps:"WPS Export", visas:"Visa Alerts", settings:"Settings",
    welcome:"Welcome back", biz:"Business Name", bizType:"Business Type",
    totalStaff:"Total Staff", emiratis:"Emiratis", schedules:"Schedules",
    messages:"Messages", fineRisk:"Fine Risk",
    generate:"Generate with AI", publish:"Publish", sendWA:"Send WhatsApp",
    addEmp:"Add Employee", save:"Save Changes", cancel:"Cancel",
    name:"Full Name", nameAr:"Arabic Name", role:"Role", phone:"Phone",
    nationality:"Nationality", eid:"Emirates ID", maxHours:"Max Hrs/Week",
    salary:"Salary AED/mo", visaExpiry:"Visa Expiry",
    scanEID:"📷 Scan Emirates ID", scanDesc:"Upload photo of Emirates ID",
    eidFound:"✓ Emirates ID detected", eidEmirati:"UAE National — Emirati",
    wpsGenerate:"Generate WPS SIF File", wpsDownload:"Download SIF",
    middayAlert:"☀️ Midday Break Law Active — 12:30PM–3PM outdoor work banned (Jun–Sep)",
    generating:"Generating...", processing:"Processing...",
    noEmps:"No employees yet. Add your first employee.",
    noSched:"Click Generate to build this week's schedule with AI.",
    noMsgs:"Publish a schedule to send WhatsApp notifications.",
    trialActive:"Trial Active", demoAcc:"Demo Account",
    email:"Email", password:"Password",
    searchPlaceholder:"Search name or role...",
    emiratisProgress:"Emiratisation Progress",
    required:"2% required 2026",
    quickActions:"Quick Actions",
    teamOverview:"Team Overview",
    latestSched:"Latest Schedule",
    viewSched:"View Schedule →",
    markRead:"Mark all read",
    clearAll:"Clear all",
    complianceCenter:"Compliance Center",
    mohreClass:"MOHRE Company Class",
    nafisTarget:"NAFIS Target 2026",
    nafisTarget30:"NAFIS Target 2030",
    visaDetector:"Visa Expiry Detector",
    expired:"Expired",
    critical:"< 30 days",
    warning:"< 90 days",
    valid:"Valid",
    noData:"No data",
    updateVisa:"Update Visa",
    wpsPayroll:"Payroll Month",
    wpsPreview:"SIF File Preview",
    wpsEmpReg:"Employee Salary Register",
    noSalary:"No salary set",
    hrModule:"HR Automation", hrTitle:"HR & Visa Automation",
    hrDesc:"MOHRE Ecosystem — Work Permits, Visas, Documents, Leave, EOS",
    workPermit:"Work Permit", permitNo:"Permit Number", permitExpiry:"Permit Expiry",
    permitStatus:"Permit Status", permitActive:"Active", permitExpired:"Expired",
    renewalDue:"Renewal Due", applyRenewal:"Apply Renewal",
    leaveBalance:"Leave Balance", annualLeave:"Annual Leave", sickLeave:"Sick Leave",
    leaveUsed:"Used", leaveRemaining:"Remaining", requestLeave:"Request Leave",
    eosCalc:"End of Service Calculator", eosGratuity:"Gratuity Amount",
    eosYears:"Years of Service", eosBasic:"Basic Salary",
    docs:"Documents", docPassport:"Passport Copy", docEID:"Emirates ID Copy",
    docVisa:"Visa Copy", docContract:"Employment Contract", docMedical:"Medical Certificate",
    docStatus:"Status", docUploaded:"On File", docMissing:"Missing",
    onboarding:"Onboarding Checklist", offboarding:"Offboarding Checklist",
    mohreActions:"MOHRE Quick Actions", mohrePortal:"MOHRE Portal",
    wpsSubmit:"WPS Submit", nafisPortal:"NAFIS Portal", mohreInspect:"Inspection Prep",
    hrAlerts:"HR Alerts", permitAlert:"Permit expiring",
    cancelVisa:"Visa Cancellation", changeStatus:"Change of Status",
    labourCard:"Labour Card", entryPermit:"Entry Permit",
    probation:"Probation", probationTitle:"Probation Tracker",
    probationActive:"On Probation", probationDone:"Probation Completed",
    probationNone:"No Join Date", joinDate:"Join Date",
    probationDaysLeft:"Days Left", probationEndDate:"Probation Ends",
    probationPct:"Progress",
    langToggle:"🇦🇪 عربي",
    platform:"AI Workforce Platform",
    startTrial:"Start Free Trial",
    learnMore:"Learn More",
    heroTag:"Built for the UAE Market",
    heroH:"Stop Scheduling on WhatsApp",
    heroSub:"JADWAL uses AI to build your weekly staff schedule in seconds, sends every employee a WhatsApp automatically, and keeps your business 100% compliant with UAE law.",
    heroCta:"Start Free — 30 Days",
    heroNote:"No credit card · No setup · Works on any phone",
  },
  ar:{
    signIn:"تسجيل الدخول", createAcc:"إنشاء حساب", signOut:"تسجيل الخروج",
    dashboard:"لوحة التحكم", employees:"الموظفون", schedule:"الجدول الذكي",
    whatsapp:"واتساب", compliance:"الامتثال", mohre:"وزارة الموارد البشرية",
    wps:"تصدير WPS", visas:"تنبيهات الإقامة", settings:"الإعدادات",
    welcome:"مرحباً بعودتك", biz:"اسم الشركة", bizType:"نوع النشاط",
    totalStaff:"إجمالي الموظفين", emiratis:"المواطنون", schedules:"الجداول",
    messages:"الرسائل", fineRisk:"خطر الغرامة",
    generate:"إنشاء بالذكاء الاصطناعي", publish:"نشر", sendWA:"إرسال واتساب",
    addEmp:"إضافة موظف", save:"حفظ التغييرات", cancel:"إلغاء",
    name:"الاسم الكامل", nameAr:"الاسم بالعربي", role:"المسمى الوظيفي", phone:"الهاتف",
    nationality:"الجنسية", eid:"الهوية الإماراتية", maxHours:"الحد الأقصى للساعات",
    salary:"الراتب درهم/شهر", visaExpiry:"تاريخ انتهاء الإقامة",
    scanEID:"📷 مسح الهوية الإماراتية", scanDesc:"حمّل صورة الهوية الإماراتية",
    eidFound:"✓ تم اكتشاف الهوية", eidEmirati:"مواطن إماراتي",
    wpsGenerate:"إنشاء ملف SIF", wpsDownload:"تحميل الملف",
    middayAlert:"☀️ قانون استراحة الظهيرة ساري — حظر العمل خارجاً 12:30–3م (يونيو–سبتمبر)",
    generating:"جاري الإنشاء...", processing:"جاري المعالجة...",
    noEmps:"لا يوجد موظفون. أضف موظفك الأول.",
    noSched:"اضغط إنشاء لبناء جدول الأسبوع بالذكاء الاصطناعي.",
    noMsgs:"انشر جدولاً لإرسال إشعارات واتساب.",
    trialActive:"فترة تجريبية", demoAcc:"حساب تجريبي",
    email:"البريد الإلكتروني", password:"كلمة المرور",
    searchPlaceholder:"ابحث بالاسم أو المسمى...",
    emiratisProgress:"تقدم التوطين",
    required:"2% مطلوب 2026",
    quickActions:"إجراءات سريعة",
    teamOverview:"نظرة عامة على الفريق",
    latestSched:"آخر جدول",
    viewSched:"عرض الجدول →",
    markRead:"تحديد الكل كمقروء",
    clearAll:"مسح الكل",
    complianceCenter:"مركز الامتثال",
    mohreClass:"تصنيف الشركة",
    nafisTarget:"هدف نافس 2026",
    nafisTarget30:"هدف نافس 2030",
    visaDetector:"كاشف انتهاء الإقامة",
    expired:"منتهية", critical:"أقل من 30 يوم", warning:"أقل من 90 يوم",
    valid:"سارية", noData:"لا بيانات",
    updateVisa:"تحديث الإقامة",
    wpsPayroll:"شهر كشف الراتب",
    wpsPreview:"معاينة ملف SIF",
    wpsEmpReg:"سجل رواتب الموظفين",
    noSalary:"لا راتب محدد",
    hrModule:"أتمتة الموارد البشرية", hrTitle:"أتمتة الموارد البشرية والإقامة",
    hrDesc:"بيئة وزارة الموارد البشرية — تصاريح العمل والإقامة والمستندات والإجازات",
    workPermit:"تصريح العمل", permitNo:"رقم التصريح", permitExpiry:"انتهاء التصريح",
    permitStatus:"حالة التصريح", permitActive:"ساري", permitExpired:"منتهي",
    renewalDue:"موعد التجديد", applyRenewal:"تقديم التجديد",
    leaveBalance:"رصيد الإجازات", annualLeave:"الإجازة السنوية", sickLeave:"الإجازة المرضية",
    leaveUsed:"مستخدم", leaveRemaining:"متبقي", requestLeave:"طلب إجازة",
    eosCalc:"حاسبة نهاية الخدمة", eosGratuity:"مبلغ المكافأة",
    eosYears:"سنوات الخدمة", eosBasic:"الراتب الأساسي",
    docs:"المستندات", docPassport:"صورة جواز السفر", docEID:"صورة الهوية الإماراتية",
    docVisa:"صورة الإقامة", docContract:"عقد العمل", docMedical:"شهادة طبية",
    docStatus:"الحالة", docUploaded:"موجود", docMissing:"مفقود",
    onboarding:"قائمة الاستقبال", offboarding:"قائمة الإنهاء",
    mohreActions:"إجراءات وزارة الموارد البشرية", mohrePortal:"بوابة الوزارة",
    wpsSubmit:"إرسال WPS", nafisPortal:"بوابة نافس", mohreInspect:"التحضير للتفتيش",
    hrAlerts:"تنبيهات الموارد البشرية", permitAlert:"تصريح ينتهي قريبًا",
    cancelVisa:"إلغاء الإقامة", changeStatus:"تغيير الوضع",
    labourCard:"بطاقة العمل", entryPermit:"تصريح الدخول",
    probation:"فترة التجربة", probationTitle:"متابعة فترة التجربة",
    probationActive:"في فترة التجربة", probationDone:"انتهت فترة التجربة",
    probationNone:"لا تاريخ توظيف", joinDate:"تاريخ الالتحاق",
    probationDaysLeft:"الأيام المتبقية", probationEndDate:"تنتهي التجربة",
    probationPct:"التقدم",
    langToggle:"🇬🇧 English",
    platform:"منصة القوى العاملة بالذكاء الاصطناعي",
    startTrial:"ابدأ تجربة مجانية",
    learnMore:"اعرف أكثر",
    heroTag:"مصمم للسوق الإماراتي",
    heroH:"أوقف جدولة الموظفين عبر واتساب",
    heroSub:"جدول يستخدم الذكاء الاصطناعي لإنشاء جدول العمل الأسبوعي في ثوانٍ، مع إخطار كل موظف تلقائياً، والامتثال الكامل للقانون الإماراتي.",
    heroCta:"ابدأ مجاناً — 30 يوماً",
    heroNote:"لا بطاقة ائتمان · لا إعداد · يعمل على أي هاتف",
  }
};

// ═══════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════
const uid = () => Math.random().toString(36).slice(2,9);
const now = () => new Date().toLocaleTimeString("en-AE",{hour:"2-digit",minute:"2-digit"});
const DAYS = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday"];
const ROLES = ["Supervisor","Team Lead","Sales Associate","Cashier","Stock Manager","Receptionist","Security","Chef","Waiter","Cleaner","Pharmacist","Nurse","Driver","Warehouse"];
const NATS = ["Emirati","Egyptian","Pakistani","Indian","Filipino","Jordanian","Lebanese","British","Sudanese","Syrian","Bangladeshi","Other"];
const BTYPES = ["Restaurant","Retail Store","Hotel","Clinic","Pharmacy","Salon","Café","Warehouse","Security Company","Other"];
const isEmirati = n => n === "Emirati";
const getPct = emps => !emps.length ? 0 : Math.round(emps.filter(e=>isEmirati(e.nationality)).length/emps.length*100);
const getFine = emps => { const g = Math.max(0, Math.ceil(emps.length*.1)-emps.filter(e=>isEmirati(e.nationality)).length); return g*7000; };
const visaDays = d => d ? Math.round((new Date(d)-new Date())/86400000) : null;
const visaStatus = d => { const v=visaDays(d); if(v===null)return null; if(v<0)return"expired"; if(v<=30)return"critical"; if(v<=90)return"warning"; return"ok"; };
const isSummer = () => { const m=new Date().getMonth()+1; return m>=6&&m<=9; };

// ── PROBATION HELPERS ─────────────────────────────────────
const PROBATION_DAYS = 180; // 6 months UAE Federal Decree Law 33/2021
const probationDaysElapsed = joinDate => joinDate ? Math.round((new Date()-new Date(joinDate))/86400000) : null;
const probationDaysLeft = joinDate => { const e=probationDaysElapsed(joinDate); if(e===null)return null; return Math.max(0, PROBATION_DAYS-e); };
const probationStatus = joinDate => {
  const e=probationDaysElapsed(joinDate);
  if(e===null) return null;
  if(e<0) return null;
  if(e<=PROBATION_DAYS) return "active";
  return "completed";
};
const probationPct = joinDate => { const e=probationDaysElapsed(joinDate); if(!e||e<0)return 0; return Math.min(100,Math.round(e/PROBATION_DAYS*100)); };
const formatProbationEnd = joinDate => {
  if(!joinDate) return "";
  const d=new Date(joinDate);
  d.setDate(d.getDate()+PROBATION_DAYS);
  return d.toLocaleDateString("en-AE",{day:"numeric",month:"long",year:"numeric"});
};

// ═══════════════════════════════════════════════════════════
// UI ATOMS
// ═══════════════════════════════════════════════════════════
const Btn = ({children,onClick,disabled,v="gold",sz="md",full,style={}}) => {
  const V={gold:{background:`linear-gradient(135deg,${C.gold},${C.goldD})`,color:"#000",border:"none"},
    outline:{background:"transparent",color:C.gold,border:`1.5px solid ${C.goldD}`},
    ghost:{background:"transparent",color:C.sub,border:`1.5px solid ${C.border}`},
    red:{background:C.redD,color:C.red,border:`1.5px solid ${C.red}40`},
    green:{background:C.greenD,color:C.green,border:`1.5px solid ${C.green}40`},
    blue:{background:C.blueD,color:C.blue,border:`1.5px solid ${C.blue}40`},
    wa:{background:C.waD,color:C.wa,border:`1.5px solid ${C.wa}40`}};
  const S={sm:"7px 13px",md:"10px 22px",lg:"14px 34px"};
  const F={sm:11,md:13,lg:15};
  return <button onClick={onClick} disabled={disabled} style={{...V[v],padding:S[sz],borderRadius:11,fontWeight:700,fontSize:F[sz],cursor:disabled?"not-allowed":"pointer",opacity:disabled?.5:1,display:"inline-flex",alignItems:"center",gap:7,width:full?"100%":"auto",justifyContent:"center",transition:"all .18s",...style}}>{children}</button>;
};

const Inp = ({label,value,onChange,type="text",placeholder,req,note,dir}) => (
  <div style={{display:"flex",flexDirection:"column",gap:4}}>
    {label&&<label style={{fontSize:10,fontWeight:700,color:C.sub,letterSpacing:.7,textTransform:"uppercase"}}>{label}{req&&<span style={{color:C.red}}> *</span>}</label>}
    <input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}
      style={{background:C.bg,border:`1.5px solid ${C.border}`,color:C.text,borderRadius:9,padding:"9px 13px",fontSize:13,outline:"none",direction:dir||"ltr"}}
      onFocus={e=>e.target.style.borderColor=C.goldD} onBlur={e=>e.target.style.borderColor=C.border}/>
    {note&&<div style={{fontSize:10,color:C.dim}}>{note}</div>}
  </div>
);

const Sel = ({label,value,onChange,options,req}) => (
  <div style={{display:"flex",flexDirection:"column",gap:4}}>
    {label&&<label style={{fontSize:10,fontWeight:700,color:C.sub,letterSpacing:.7,textTransform:"uppercase"}}>{label}{req&&<span style={{color:C.red}}> *</span>}</label>}
    <select value={value} onChange={e=>onChange(e.target.value)}
      style={{background:C.bg,border:`1.5px solid ${C.border}`,color:C.text,borderRadius:9,padding:"9px 13px",fontSize:13,outline:"none",cursor:"pointer"}}>
      {options.map(o=><option key={o.v||o} value={o.v||o}>{o.l||o}</option>)}
    </select>
  </div>
);

const Bdg = ({children,color=C.gold,style={}}) => (
  <span style={{background:`${color}18`,color,border:`1px solid ${color}30`,borderRadius:6,padding:"2px 9px",fontSize:10,fontWeight:700,whiteSpace:"nowrap",...style}}>{children}</span>
);

const Card = ({children,style={},glow}) => (
  <div style={{background:C.card,border:`1.5px solid ${glow?C.gold:C.border}`,borderRadius:18,padding:20,animation:glow?"glow 3.5s ease infinite":undefined,...style}}>{children}</div>
);

const Modal = ({title,onClose,children,w=520}) => (
  <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.8)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:200,padding:16}} onClick={onClose}>
    <div style={{background:C.card,border:`1.5px solid ${C.border}`,borderRadius:22,padding:26,width:"100%",maxWidth:w,maxHeight:"92vh",overflowY:"auto",animation:"pop .38s cubic-bezier(.16,1,.3,1) both"}} onClick={e=>e.stopPropagation()}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18}}>
        <div style={{fontFamily:"'Syne',sans-serif",fontSize:17,fontWeight:700}}>{title}</div>
        <button onClick={onClose} style={{background:"none",border:"none",color:C.dim,fontSize:22,cursor:"pointer",lineHeight:1}}>✕</button>
      </div>
      {children}
    </div>
  </div>
);

const Toast = ({msg,type="success",onClose}) => {
  useEffect(()=>{const t=setTimeout(onClose,3600);return()=>clearTimeout(t);},[]);
  const cols={success:C.green,error:C.red,info:C.gold,warning:C.orange};
  return <div style={{position:"fixed",bottom:24,right:24,zIndex:400,background:C.card,border:`1.5px solid ${cols[type]}`,borderRadius:14,padding:"11px 20px",fontSize:13,fontWeight:600,color:cols[type],boxShadow:"0 8px 36px rgba(0,0,0,.55)",animation:"waPop .38s ease both",display:"flex",alignItems:"center",gap:8,maxWidth:320}}>
    {type==="success"?"✓":type==="error"?"✗":type==="warning"?"⚠":"ℹ"} {msg}
  </div>;
};

const SectionTitle = ({tag,h,sub,tagColor=C.gold}) => (
  <div style={{textAlign:"center",marginBottom:52}}>
    <div style={{display:"inline-block",border:`1px solid ${tagColor}50`,borderRadius:20,padding:"5px 16px",fontSize:11,color:tagColor,letterSpacing:1,marginBottom:14,fontWeight:700}}>{tag}</div>
    <h2 style={{fontFamily:"'Syne',sans-serif",fontSize:"clamp(24px,3.5vw,42px)",fontWeight:800,lineHeight:1.12,marginBottom:h&&sub?12:0}}>{h}</h2>
    {sub&&<p style={{color:C.sub,fontSize:15,maxWidth:600,margin:"0 auto",lineHeight:1.75}}>{sub}</p>}
  </div>
);

// ═══════════════════════════════════════════════════════════
// LANDING PAGE
// ═══════════════════════════════════════════════════════════
const TICKER_EN = ["AI schedules in seconds","WhatsApp auto-notify","Emiratisation compliant","WPS 2.0 export","Visa expiry alerts","Emirates ID scanner","Arabic & English","AED 299/month"];
const TICKER_AR = ["جداول بالذكاء الاصطناعي","إشعارات واتساب تلقائية","امتثال التوطين","تصدير WPS 2.0","تنبيهات الإقامة","ماسح الهوية","عربي وإنجليزي","٢٩٩ درهم شهرياً"];

function Landing({onGoApp, lang, setLang}) {
  const t = TR[lang];
  const rtl = lang==="ar";

  const features = [
    {icon:"🤖",c:C.gold,title:lang==="en"?"AI Schedule Generator":"مولد الجداول الذكي",desc:lang==="en"?"Claude AI builds a compliant schedule for your entire team in under 10 seconds. UAE labor law enforced automatically.":"يبني الذكاء الاصطناعي جدولاً متوافقاً للفريق كاملاً في أقل من ١٠ ثوانٍ. قوانين العمل الإماراتية مطبقة تلقائياً."},
    {icon:"💬",c:C.wa,title:lang==="en"?"Auto WhatsApp Alerts":"إشعارات واتساب تلقائية",desc:lang==="en"?"Every employee gets a personalized WhatsApp the moment you publish. No group chaos. Zero manual effort.":"كل موظف يتلقى واتساب شخصياً لحظة النشر. لا فوضى جماعية. صفر جهد يدوي."},
    {icon:"⚖️",c:C.blue,title:lang==="en"?"Emiratisation / NAFIS":"التوطين / نافس",desc:lang==="en"?"Real-time quota tracking, company class A/B/C, exact fine risk, milestone alerts to 2030.":"متابعة الحصة في الوقت الفعلي، تصنيف الشركة، خطر الغرامات، تنبيهات المراحل حتى ٢٠٣٠."},
    {icon:"💰",c:C.green,title:lang==="en"?"WPS 2.0 SIF Export":"تصدير WPS 2.0",desc:lang==="en"?"Generate your UAE Wage Protection System file automatically. Download and submit in one click. Mandatory July 2026.":"أنشئ ملف نظام حماية الأجور تلقائياً. حمّل وأرسل بنقرة واحدة. إلزامي يوليو ٢٠٢٦."},
    {icon:"🪪",c:C.orange,title:lang==="en"?"AI Emirates ID Scanner":"ماسح الهوية الإماراتية",desc:lang==="en"?"Scan any Emirates ID with camera. Auto-detects UAE nationals. No manual entry. Instant verification.":"امسح أي هوية إماراتية بالكاميرا. يكشف المواطنين تلقائياً. لا إدخال يدوي."},
    {icon:"🌐",c:"#c084fc",title:lang==="en"?"Bilingual Arabic & English":"عربي وإنجليزي",desc:lang==="en"?"Full Arabic interface with RTL layout. Switch with one tap. Every label, button, and notification.":"واجهة عربية كاملة مع تخطيط RTL. تبديل بنقرة واحدة. كل شيء بالعربية."},
    {icon:"🛂",c:C.red,title:lang==="en"?"Visa Expiry Detector":"كاشف انتهاء الإقامة",desc:lang==="en"?"Color-coded alerts 90, 30, and 7 days before any visa expires. Never risk illegal scheduling.":"تنبيهات ملونة قبل ٩٠ و٣٠ و٧ أيام من انتهاء أي إقامة. لا تجدول عمالاً غير نظاميين."},
    {icon:"☀️",c:C.orange,title:lang==="en"?"Midday Break Law Auto-Block":"حظر قانون استراحة الظهيرة",desc:lang==="en"?"June–Sep: 12:30PM–3PM outdoor work ban. JADWAL blocks this automatically in every AI schedule.":"يونيو–سبتمبر: حظر العمل خارجاً ١٢:٣٠–٣م. جدول يحظره تلقائياً في كل جدول."},
  ];

  const plans = [
    {name:lang==="en"?"Starter":"المبتدئ",price:lang==="en"?"AED 299":"٢٩٩ درهم",per:lang==="en"?"/month":"شهرياً",staff:lang==="en"?"Up to 20 staff":"حتى ٢٠ موظفاً",hot:false},
    {name:lang==="en"?"Growth":"النمو",price:lang==="en"?"AED 699":"٦٩٩ درهم",per:lang==="en"?"/month":"شهرياً",staff:lang==="en"?"Up to 100 staff":"حتى ١٠٠ موظف",hot:true},
    {name:lang==="en"?"Enterprise":"المؤسسي",price:lang==="en"?"Custom":"مخصص",per:"",staff:lang==="en"?"100+ staff":"١٠٠+ موظف",hot:false},
  ];

  const ticker = lang==="en"?TICKER_EN:TICKER_AR;

  return (
    <div dir={rtl?"rtl":"ltr"} style={{fontFamily:rtl?"'Noto Kufi Arabic',sans-serif":"'Plus Jakarta Sans',sans-serif"}}>

      {/* TICKER */}
      <div style={{background:`linear-gradient(90deg,${C.goldD},${C.gold},${C.goldD})`,padding:"7px 0",overflow:"hidden",whiteSpace:"nowrap"}}>
        <div style={{display:"inline-flex",animation:"ticker 22s linear infinite"}}>
          {[...ticker,...ticker].map((item,i)=><span key={i} style={{color:"#000",fontWeight:700,fontSize:11,padding:"0 26px",letterSpacing:.8}}>✦ {item}</span>)}
        </div>
      </div>

      {/* NAV */}
      <nav style={{position:"sticky",top:0,zIndex:100,background:"rgba(7,7,13,.96)",backdropFilter:"blur(20px)",borderBottom:`1px solid ${C.border}`,padding:"13px 0"}}>
        <div style={{maxWidth:1160,margin:"0 auto",padding:"0 24px",display:"flex",justifyContent:"space-between",alignItems:"center",gap:16}}>
          <div style={{fontFamily:"'Syne',sans-serif",fontSize:22,fontWeight:800,letterSpacing:5,background:`linear-gradient(135deg,${C.goldL},${C.gold})`,WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>JADWAL.</div>
          <div style={{display:"flex",gap:10,alignItems:"center"}}>
            <button onClick={()=>setLang(l=>l==="en"?"ar":"en")} style={{padding:"7px 14px",borderRadius:8,border:`1px solid ${C.goldD}`,background:`${C.gold}12`,color:C.gold,cursor:"pointer",fontFamily:"inherit",fontSize:12,fontWeight:700}}>{t.langToggle}</button>
            <Btn onClick={onGoApp} sz="sm">{t.startTrial}</Btn>
          </div>
        </div>
      </nav>

      {/* HERO */}
      <section style={{padding:"90px 24px 70px",background:`radial-gradient(ellipse 90% 60% at 50% -5%, ${C.glow}, transparent 60%), ${C.bg}`,textAlign:"center"}}>
        <div style={{maxWidth:900,margin:"0 auto"}}>
          <div className="fu" style={{display:"inline-flex",alignItems:"center",gap:6,border:`1px solid ${C.goldD}`,borderRadius:20,padding:"5px 16px",fontSize:11,color:C.gold,letterSpacing:1,marginBottom:24,fontWeight:700}}>🇦🇪 {t.heroTag}</div>
          <h1 className="fu" style={{animationDelay:".08s",fontFamily:"'Syne',sans-serif",fontSize:"clamp(34px,5.5vw,70px)",fontWeight:800,lineHeight:1.08,marginBottom:18}}>
            <span style={{background:`linear-gradient(135deg,${C.goldL},${C.gold})`,WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>{t.heroH}</span>
          </h1>
          <p className="fu" style={{animationDelay:".15s",fontSize:"clamp(14px,1.7vw,18px)",color:C.sub,maxWidth:660,margin:"0 auto 36px",lineHeight:1.8}}>{t.heroSub}</p>
          <div className="fu" style={{animationDelay:".22s",display:"flex",gap:14,justifyContent:"center",flexWrap:"wrap",marginBottom:18}}>
            <button onClick={onGoApp} style={{background:`linear-gradient(135deg,${C.gold},${C.goldD})`,border:"none",borderRadius:14,padding:"16px 38px",fontSize:15,fontWeight:800,color:"#000",cursor:"pointer",fontFamily:"inherit",boxShadow:`0 12px 36px rgba(201,168,76,.35)`,animation:"glow 3.5s ease infinite"}}>{t.heroCta} →</button>
            <Btn v="ghost" sz="lg">▶ {t.learnMore}</Btn>
          </div>
          <div className="fu" style={{animationDelay:".3s",fontSize:12,color:C.dim,marginBottom:60}}>{t.heroNote}</div>

          {/* Dashboard preview */}
          <div className="fu float" style={{animationDelay:".4s",background:`linear-gradient(135deg,${C.card},#0e0e22)`,border:`1.5px solid ${C.goldD}`,borderRadius:22,padding:22,boxShadow:`0 28px 70px rgba(0,0,0,.5), 0 0 0 1px ${C.goldD}30`,maxWidth:840,margin:"0 auto"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16,flexWrap:"wrap",gap:8}}>
              <div style={{fontFamily:"'Syne',sans-serif",fontSize:13,fontWeight:700}}>JADWAL · Week Apr 13–18 · Dubai Mall Retail</div>
              <div style={{display:"flex",gap:7}}><Bdg color={C.green}>✓ Published</Bdg><Bdg color={C.wa}>💬 WA Sent</Bdg><Bdg color={C.blue}>⚖️ Compliant</Bdg></div>
            </div>
            <div style={{overflowX:"auto"}}>
              <table style={{width:"100%",borderCollapse:"collapse",fontSize:11}}>
                <thead><tr>{["Employee","Sun","Mon","Tue","Wed","Thu","Fri","Status"].map(h=><th key={h} style={{padding:"7px 8px",color:C.sub,borderBottom:`1px solid ${C.border}`,textAlign:"left",fontSize:10,fontWeight:700,letterSpacing:.5,textTransform:"uppercase",whiteSpace:"nowrap"}}>{h}</th>)}</tr></thead>
                <tbody>
                  {[["Ahmed Al Mansouri","☀️AM","☀️AM","🌤PM","☀️AM","☀️AM","☀️AM","🇦🇪 Emirati"],
                    ["Fatima Hassan","🌤PM","☀️AM","☀️AM","—","🌤PM","☀️AM","🇦🇪 Emirati"],
                    ["Khalid Ibrahim","☀️AM","—","🌤PM","☀️AM","☀️AM","—","Egyptian"],
                    ["Sara Al Zaabi","🌤PM","🌤PM","☀️AM","🌤PM","—","☀️AM","🇦🇪 Emirati"]].map((row,i)=>(
                    <tr key={i} style={{borderBottom:`1px solid ${C.border}10`}}>
                      <td style={{padding:"8px 8px",fontWeight:700,fontSize:12,whiteSpace:"nowrap"}}>{row[0]}</td>
                      {row.slice(1,7).map((c,j)=><td key={j} style={{padding:"8px 6px"}}><span style={{padding:"2px 7px",borderRadius:5,fontSize:10,fontWeight:600,background:c==="—"?"#131320":c.includes("AM")?C.orangeD:C.blueD,color:c==="—"?C.dim:c.includes("AM")?C.orange:C.blue,border:`1px solid ${c==="—"?C.border:c.includes("AM")?C.orange+"35":C.blue+"35"}`}}>{c}</span></td>)}
                      <td style={{padding:"8px 6px"}}><Bdg color={row[7].includes("Emirati")?C.green:C.sub}>{row[7]}</Bdg></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div style={{display:"flex",gap:10,marginTop:14,flexWrap:"wrap"}}>
              {[{l:"Emiratisation",v:"75% ✓",c:C.green},{l:"Fine Risk",v:"AED 0",c:C.green},{l:"WPS",v:"Compliant",c:C.green},{l:"Visas",v:"0 expired",c:C.green}].map((s,i)=>(
                <div key={i} style={{background:C.bg,borderRadius:9,padding:"8px 14px",border:`1px solid ${C.border}`,flex:"1 1 110px",textAlign:"center"}}>
                  <div style={{fontSize:10,color:C.sub}}>{s.l}</div>
                  <div style={{fontWeight:800,fontSize:13,color:s.c,marginTop:2}}>{s.v}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section style={{padding:"80px 24px",background:C.bg}}>
        <div style={{maxWidth:1100,margin:"0 auto"}}>
          <SectionTitle tag={lang==="en"?"8 UAE-Specific Features":"٨ مميزات إماراتية"} h={lang==="en"?"Everything Built for the UAE":"كل شيء مبني للإمارات"} tagColor={C.gold}/>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(250px,1fr))",gap:14}}>
            {features.map((f,i)=>(
              <div key={i} className="fu" style={{animationDelay:`${i*.05}s`,background:C.card,border:`1.5px solid ${C.border}`,borderRadius:18,padding:22,transition:"all .2s",cursor:"default"}}
                onMouseEnter={e=>{e.currentTarget.style.borderColor=f.c+"60";e.currentTarget.style.transform="translateY(-3px)";}}
                onMouseLeave={e=>{e.currentTarget.style.borderColor=C.border;e.currentTarget.style.transform="none";}}>
                <div style={{width:46,height:46,borderRadius:13,background:`${f.c}18`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,marginBottom:12}}>{f.icon}</div>
                <div style={{fontWeight:700,fontSize:14,color:f.c,marginBottom:7}}>{f.title}</div>
                <div style={{fontSize:12,color:C.sub,lineHeight:1.7}}>{f.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section style={{padding:"80px 24px",background:`linear-gradient(180deg,${C.bg},#0a0a14)`}}>
        <div style={{maxWidth:1000,margin:"0 auto"}}>
          <SectionTitle tag={lang==="en"?"Pricing":"الأسعار"} h={lang==="en"?"Simple, Transparent Pricing":"أسعار بسيطة وشفافة"} sub={lang==="en"?"30-day free trial. No credit card. All features included.":"تجربة مجانية ٣٠ يوماً. لا بطاقة ائتمان. جميع المميزات مشمولة."} tagColor={C.gold}/>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))",gap:16}}>
            {plans.map((p,i)=>(
              <div key={i} className="fu" style={{animationDelay:`${i*.1}s`,background:p.hot?`linear-gradient(135deg,${C.card},#0e0e22)`:C.card,border:`2px solid ${p.hot?C.gold:C.border}`,borderRadius:22,padding:26,position:"relative",animation:p.hot?"glow 3.5s ease infinite":undefined}}>
                {p.hot&&<div style={{position:"absolute",top:-12,left:"50%",transform:"translateX(-50%)",background:`linear-gradient(135deg,${C.gold},${C.goldD})`,borderRadius:20,padding:"3px 16px",fontSize:10,fontWeight:700,color:"#000",whiteSpace:"nowrap"}}>{lang==="en"?"Most Popular":"الأكثر شعبية"}</div>}
                <div style={{fontFamily:"'Syne',sans-serif",fontSize:17,fontWeight:700,color:p.hot?C.goldL:C.text,marginBottom:4}}>{p.name}</div>
                <div style={{fontSize:11,color:C.sub,marginBottom:14}}>{p.staff}</div>
                <div style={{fontFamily:"'Syne',sans-serif",fontSize:32,fontWeight:800,color:p.hot?C.gold:C.text,marginBottom:4}}>{p.price}</div>
                <div style={{fontSize:12,color:C.sub,marginBottom:22}}>{p.per}</div>
                <Btn onClick={onGoApp} v={p.hot?"gold":"outline"} full>{lang==="en"?"Start Free Trial":"ابدأ تجربة مجانية"}</Btn>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section style={{padding:"80px 24px",textAlign:"center",background:`radial-gradient(ellipse 70% 50% at 50% 50%, ${C.glow}, transparent 65%), ${C.bg}`}}>
        <div style={{maxWidth:640,margin:"0 auto"}}>
          <h2 className="fu" style={{fontFamily:"'Syne',sans-serif",fontSize:"clamp(26px,4vw,46px)",fontWeight:800,lineHeight:1.1,marginBottom:14}}>{lang==="en"?"Ready to Replace WhatsApp?":"جاهز للتخلص من واتساب؟"}</h2>
          <p className="fu" style={{animationDelay:".1s",fontSize:15,color:C.sub,marginBottom:32,lineHeight:1.75}}>{lang==="en"?"Join UAE businesses already using JADWAL. 30 days free. Setup in 10 minutes.":"انضم إلى الشركات الإماراتية التي تستخدم جدول. ٣٠ يوماً مجاناً. إعداد في ١٠ دقائق."}</p>
          <button className="fu" onClick={onGoApp} style={{animationDelay:".2s",background:`linear-gradient(135deg,${C.gold},${C.goldD})`,border:"none",borderRadius:14,padding:"17px 44px",fontSize:15,fontWeight:800,color:"#000",cursor:"pointer",fontFamily:"inherit",boxShadow:`0 14px 44px rgba(201,168,76,.38)`,animation:"glow 3.5s ease infinite"}}>
            {lang==="en"?"Enter JADWAL Platform →":"ادخل منصة جدول →"}
          </button>
          <div className="fu" style={{animationDelay:".3s",fontSize:12,color:C.dim,marginTop:14}}>{t.heroNote}</div>
        </div>
      </section>

      <footer style={{background:C.card,borderTop:`1px solid ${C.border}`,padding:"36px 24px",textAlign:"center"}}>
        <div style={{fontFamily:"'Syne',sans-serif",fontSize:18,fontWeight:800,letterSpacing:4,background:`linear-gradient(135deg,${C.goldL},${C.gold})`,WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",marginBottom:8}}>JADWAL.</div>
        <div style={{fontSize:12,color:C.dim}}>© 2026 JADWAL Technologies LLC · Meydan Free Zone, Dubai, UAE 🇦🇪</div>
      </footer>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// MAIN APP
// ═══════════════════════════════════════════════════════════
export default function App() {
  const [screen, setScreen] = useState("landing"); // landing | auth | app
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState("");
  const [emps, setEmps] = useState([]);
  const [scheds, setScheds] = useState([]);
  const [notifs, setNotifs] = useState([]);
  const [page, setPage] = useState("dashboard");
  const [toast, setToast] = useState(null);
  const [boot, setBoot] = useState(true);
  const [lang, setLang] = useState("en");

  useEffect(()=>{
    // init demo
    if(!localStorage.getItem("jadwal_v3_init")){
      const demo={id:"demo",name:"Thomas",email:"demo@jadwal.ae",pass:"demo123",biz:"JADWAL Demo Store — Dubai Mall",bizType:"Retail Store",phone:"+971554660881",plan:"trial",joined:new Date().toISOString()};
      localStorage.setItem("jadwal_u_demo@jadwal.ae",JSON.stringify(demo));
      localStorage.setItem("jadwal_e_demo@jadwal.ae",JSON.stringify([
        {id:uid(),name:"Ahmed Al Mansouri",nameAr:"أحمد المنصوري",role:"Supervisor",phone:"+971501234567",nationality:"Emirati",eid:"784-1990-1234567-1",maxHours:40,active:true,visaExpiry:"2027-08-15",salary:8000,joinDate:"2021-03-10",permitNo:"WP-2021-001234",permitExpiry:"2027-08-15",annualLeave:30,annualUsed:12,sickLeave:60,sickUsed:2,docs:{passport:true,eid:true,visa:true,contract:true,medical:true}},
        {id:uid(),name:"Fatima Hassan",nameAr:"فاطمة حسن",role:"Cashier",phone:"+971552345678",nationality:"Emirati",eid:"784-1992-2345678-2",maxHours:40,active:true,visaExpiry:"2026-12-20",salary:5000,joinDate:"2023-09-01",permitNo:"WP-2023-005678",permitExpiry:"2026-12-20",annualLeave:30,annualUsed:5,sickLeave:60,sickUsed:0,docs:{passport:true,eid:true,visa:true,contract:true,medical:false}},
        {id:uid(),name:"Khalid Ibrahim",nameAr:"خالد إبراهيم",role:"Sales Associate",phone:"+971523456789",nationality:"Egyptian",eid:"",maxHours:40,active:true,visaExpiry:"2024-06-01",salary:4500,joinDate:"2026-01-15",permitNo:"WP-2026-009012",permitExpiry:"2026-05-20",annualLeave:30,annualUsed:20,sickLeave:60,sickUsed:8,docs:{passport:true,eid:false,visa:true,contract:false,medical:true}},
        {id:uid(),name:"Sara Al Zaabi",nameAr:"سارة الزعابي",role:"Team Lead",phone:"+971564567890",nationality:"Emirati",eid:"784-1995-3456789-3",maxHours:40,active:true,visaExpiry:"2027-03-10",salary:7000,joinDate:"2022-06-20",permitNo:"WP-2022-003456",permitExpiry:"2027-03-10",annualLeave:30,annualUsed:8,sickLeave:60,sickUsed:5,docs:{passport:true,eid:true,visa:true,contract:true,medical:true}},
        {id:uid(),name:"Omar Rashid",nameAr:"عمر راشد",role:"Stock Manager",phone:"+971505678901",nationality:"Pakistani",eid:"",maxHours:40,active:true,visaExpiry:"2025-11-05",salary:4000,joinDate:"2026-03-01",permitNo:"WP-2026-007890",permitExpiry:"2026-04-15",annualLeave:30,annualUsed:30,sickLeave:60,sickUsed:15,docs:{passport:false,eid:false,visa:true,contract:true,medical:false}},
        {id:uid(),name:"Layla Nasser",nameAr:"ليلى ناصر",role:"Cashier",phone:"+971556789012",nationality:"Filipino",eid:"",maxHours:36,active:true,visaExpiry:"2026-04-22",salary:3800,joinDate:"2025-12-10",permitNo:"WP-2025-011234",permitExpiry:"2026-04-22",annualLeave:30,annualUsed:3,sickLeave:60,sickUsed:1,docs:{passport:true,eid:false,visa:true,contract:true,medical:true}},
      ]));
      localStorage.setItem("jadwal_s_demo@jadwal.ae","[]");
      localStorage.setItem("jadwal_n_demo@jadwal.ae","[]");
      localStorage.setItem("jadwal_v3_init","1");
    }
    // restore session
    try {
      const sess = JSON.parse(localStorage.getItem("jadwal_v3_sess")||"null");
      if(sess){const{u,e}=sess; doLogin(u,e);}
    } catch{}
    setBoot(false);
  },[]);

  const doLogin=(u,e)=>{
    setUser(u);setEmail(e);
    setEmps(JSON.parse(localStorage.getItem(`jadwal_e_${e}`)||"[]"));
    setScheds(JSON.parse(localStorage.getItem(`jadwal_s_${e}`)||"[]"));
    setNotifs(JSON.parse(localStorage.getItem(`jadwal_n_${e}`)||"[]"));
    localStorage.setItem("jadwal_v3_sess",JSON.stringify({u,e}));
    setScreen("app");setPage("dashboard");
  };
  const doLogout=()=>{setUser(null);setEmail("");setScreen("landing");localStorage.removeItem("jadwal_v3_sess");};
  const saveE=l=>{setEmps(l);localStorage.setItem(`jadwal_e_${email}`,JSON.stringify(l));};
  const saveS=l=>{setScheds(l);localStorage.setItem(`jadwal_s_${email}`,JSON.stringify(l));};
  const saveN=l=>{setNotifs(l);localStorage.setItem(`jadwal_n_${email}`,JSON.stringify(l));};
  const addToast=(msg,type="success")=>setToast({msg,type});

  const t = TR[lang];
  const rtl = lang==="ar";
  const active = emps.filter(e=>e.active);
  const pct = getPct(active);
  const fine = getFine(active);
  const unread = notifs.filter(n=>!n.read).length;
  const expVisa = active.filter(e=>visaStatus(e.visaExpiry)==="expired").length;
  const warnVisa = active.filter(e=>["critical","warning"].includes(visaStatus(e.visaExpiry))).length;
  const onProbation = active.filter(e=>probationStatus(e.joinDate)==="active").length;
  const summer = isSummer();

  if(boot) return <div style={{minHeight:"100vh",background:C.bg,display:"flex",alignItems:"center",justifyContent:"center"}}><div className="spinner" style={{width:30,height:30}}/></div>;

  if(screen==="landing") return <><style>{css}</style><Landing onGoApp={()=>setScreen("auth")} lang={lang} setLang={setLang}/></>;

  if(screen==="auth") return <><style>{css}</style><AuthScreen onLogin={doLogin} onBack={()=>setScreen("landing")} lang={lang} setLang={setLang} t={t}/></>;

  const hrAlerts = active.filter(e=>e.permitExpiry&&Math.round((new Date(e.permitExpiry)-new Date())/86400000)<=60).length;

  const NAV=[
    {id:"dashboard",icon:"📊",label:t.dashboard},
    {id:"employees",icon:"👥",label:t.employees},
    {id:"schedule",icon:"🗓",label:t.schedule},
    {id:"whatsapp",icon:"💬",label:t.whatsapp,badge:unread},
    {id:"compliance",icon:"⚖️",label:t.compliance},
    {id:"mohre",icon:"🏛️",label:t.mohre},
    {id:"wps",icon:"💰",label:t.wps},
    {id:"visas",icon:"🛂",label:t.visas,badge:expVisa+warnVisa},
    {id:"probation",icon:"🆕",label:t.probation,badge:onProbation},
    {id:"hr",icon:"📋",label:t.hrModule||"HR Automation",badge:hrAlerts},
    {id:"settings",icon:"⚙️",label:t.settings},
  ];

  return <>
    <style>{css}</style>
    <div dir={rtl?"rtl":"ltr"} style={{display:"flex",minHeight:"100vh",fontFamily:rtl?"'Noto Kufi Arabic',sans-serif":"'Plus Jakarta Sans',sans-serif"}}>
      {/* SIDEBAR */}
      <div style={{width:212,background:C.card,borderRight:!rtl?`1px solid ${C.border}`:"none",borderLeft:rtl?`1px solid ${C.border}`:"none",display:"flex",flexDirection:"column",position:"sticky",top:0,height:"100vh",flexShrink:0}}>
        <div style={{padding:"18px 16px 14px",borderBottom:`1px solid ${C.border}`}}>
          <div style={{fontFamily:"'Syne',sans-serif",fontSize:20,fontWeight:800,letterSpacing:5,background:`linear-gradient(135deg,${C.goldL},${C.gold})`,WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>JADWAL.</div>
          <div style={{fontSize:9,color:C.dim,letterSpacing:1.4,marginTop:1}}>{t.platform.toUpperCase()}</div>
        </div>
        <div style={{padding:"10px 14px",borderBottom:`1px solid ${C.border}`}}>
          <div style={{fontWeight:700,fontSize:12,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{user?.biz}</div>
          <div style={{fontSize:10,color:C.dim,marginTop:1}}>{user?.bizType} · 🎁 {t.trialActive}</div>
        </div>
        <nav style={{flex:1,padding:"8px 7px",display:"flex",flexDirection:"column",gap:1,overflowY:"auto"}}>
          {NAV.map(n=>(
            <button key={n.id} onClick={()=>setPage(n.id)} style={{display:"flex",alignItems:"center",gap:8,padding:"9px 10px",borderRadius:10,border:"none",cursor:"pointer",background:page===n.id?`${C.gold}12`:"transparent",borderLeft:!rtl&&page===n.id?`2.5px solid ${C.gold}`:"2.5px solid transparent",borderRight:rtl&&page===n.id?`2.5px solid ${C.gold}`:"2.5px solid transparent",color:page===n.id?C.gold:C.sub,fontWeight:page===n.id?700:400,fontSize:12,fontFamily:"inherit",transition:"all .15s"}}>
              <span style={{fontSize:14}}>{n.icon}</span>{n.label}
              {n.badge>0&&<span style={{marginLeft:rtl?"0":"auto",marginRight:rtl?"auto":"0",background:C.red,color:"#fff",borderRadius:"50%",width:16,height:16,display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,fontWeight:800}}>{n.badge}</span>}
            </button>
          ))}
        </nav>
        <div style={{padding:"10px 14px",borderTop:`1px solid ${C.border}`,display:"flex",alignItems:"center",gap:8}}>
          <div style={{width:30,height:30,borderRadius:9,background:`linear-gradient(135deg,${C.goldD},${C.gold}55)`,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:11,color:C.goldL,flexShrink:0}}>{user?.name?.[0]}</div>
          <div style={{flex:1,minWidth:0,fontSize:11,fontWeight:700,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{user?.name}</div>
          <button onClick={()=>setLang(l=>l==="en"?"ar":"en")} style={{background:"none",border:"none",color:C.gold,cursor:"pointer",fontSize:11,fontWeight:700,padding:2}}>{lang==="en"?"ع":"En"}</button>
          <button onClick={doLogout} style={{background:"none",border:"none",color:C.dim,cursor:"pointer",fontSize:13,padding:2}}>⏻</button>
        </div>
      </div>

      {/* CONTENT */}
      <div style={{flex:1,overflowY:"auto"}}>
        {summer&&<div style={{background:`linear-gradient(90deg,${C.orangeD},#2a1400)`,borderBottom:`1px solid ${C.orange}40`,padding:"8px 24px",fontSize:12,color:C.orange,fontWeight:600}}>{t.middayAlert}</div>}
        <div style={{padding:"13px 24px",borderBottom:`1px solid ${C.border}`,display:"flex",justifyContent:"space-between",alignItems:"center",background:C.card,position:"sticky",top:summer?28:0,zIndex:50}}>
          <div style={{fontFamily:"'Syne',sans-serif",fontSize:16,fontWeight:700}}>{NAV.find(n=>n.id===page)?.icon} {NAV.find(n=>n.id===page)?.label}</div>
          <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
            {fine>0&&<Bdg color={C.red}>🚨 AED {fine.toLocaleString()}</Bdg>}
            {expVisa>0&&<Bdg color={C.red}>🛂 {expVisa} expired</Bdg>}
            {onProbation>0&&<Bdg color={C.purple}>🆕 {onProbation} probation</Bdg>}
            <Bdg color={pct>=2?C.green:C.orange}>{pct}% {t.emiratis}</Bdg>
          </div>
        </div>
        <div style={{padding:24}}>
          {page==="dashboard"&&<DashPage t={t} user={user} emps={active} scheds={scheds} notifs={notifs} pct={pct} fine={fine} setPage={setPage} expVisa={expVisa} warnVisa={warnVisa} lang={lang}/>}
          {page==="employees"&&<EmpsPage t={t} emps={emps} saveE={saveE} addToast={addToast} lang={lang}/>}
          {page==="schedule"&&<SchedPage t={t} emps={active} scheds={scheds} saveS={saveS} notifs={notifs} saveN={saveN} addToast={addToast} lang={lang} summer={summer}/>}
          {page==="whatsapp"&&<WAPage t={t} notifs={notifs} saveN={saveN} emps={active}/>}
          {page==="compliance"&&<CompliancePage t={t} emps={active} pct={pct} fine={fine}/>}
          {page==="mohre"&&<MOHREPage t={t} emps={active} pct={pct} fine={fine}/>}
          {page==="wps"&&<WPSPage t={t} emps={active} addToast={addToast}/>}
          {page==="visas"&&<VisaPage t={t} emps={emps} saveE={saveE} addToast={addToast}/>}
          {page==="probation"&&<ProbationPage t={t} emps={emps} saveE={saveE} addToast={addToast} lang={lang}/>}
          {page==="hr"&&<HRPage t={t} emps={emps} saveE={saveE} addToast={addToast} lang={lang}/>}
          {page==="settings"&&<SettingsPage t={t} user={user} setUser={u=>{setUser(u);localStorage.setItem(`jadwal_u_${email}`,JSON.stringify(u));}} addToast={addToast} doLogout={doLogout} lang={lang} setLang={setLang}/>}
        </div>
      </div>
    </div>
    {toast&&<Toast msg={toast.msg} type={toast.type} onClose={()=>setToast(null)}/>}
  </>;
}

// ═══════════════════════════════════════════════════════════
// AUTH
// ═══════════════════════════════════════════════════════════
function AuthScreen({onLogin,onBack,lang,setLang,t}){
  const [mode,setMode]=useState("login");
  const [f,setF]=useState({name:"",email:"",pass:"",biz:"",bizType:"Retail Store",phone:""});
  const [err,setErr]=useState(""); const [busy,setBusy]=useState(false);
  const s=k=>v=>setF(p=>({...p,[k]:v}));
  const rtl=lang==="ar";

  const submit=async()=>{
    setErr("");setBusy(true);
    await new Promise(r=>setTimeout(r,700));
    if(mode==="login"){
      const stored=JSON.parse(localStorage.getItem(`jadwal_u_${f.email}`)||"null");
      if(stored&&stored.pass===f.pass) onLogin(stored,f.email);
      else setErr(lang==="en"?"Invalid email or password.":"البريد أو كلمة المرور غير صحيحة.");
    } else {
      if(!f.name||!f.email||!f.pass||!f.biz){setErr(lang==="en"?"All fields required.":"جميع الحقول مطلوبة.");setBusy(false);return;}
      const u={id:uid(),name:f.name,email:f.email,pass:f.pass,biz:f.biz,bizType:f.bizType,phone:f.phone,plan:"trial",joined:new Date().toISOString()};
      localStorage.setItem(`jadwal_u_${f.email}`,JSON.stringify(u));
      localStorage.setItem(`jadwal_e_${f.email}`,"[]");
      localStorage.setItem(`jadwal_s_${f.email}`,"[]");
      localStorage.setItem(`jadwal_n_${f.email}`,"[]");
      onLogin(u,f.email);
    }
    setBusy(false);
  };

  return (
    <div dir={rtl?"rtl":"ltr"} style={{minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:`radial-gradient(ellipse 80% 55% at 50% -5%,${C.glow},transparent 65%),${C.bg}`,padding:20,fontFamily:rtl?"'Noto Kufi Arabic',sans-serif":"'Plus Jakarta Sans',sans-serif"}}>
      <div style={{width:"100%",maxWidth:400}}>
        <button onClick={onBack} style={{background:"none",border:"none",color:C.sub,cursor:"pointer",fontSize:13,marginBottom:20,display:"flex",alignItems:"center",gap:6,fontFamily:"inherit"}}>← {lang==="en"?"Back to website":"العودة للموقع"}</button>
        <div className="fu" style={{textAlign:"center",marginBottom:30}}>
          <div style={{fontFamily:"'Syne',sans-serif",fontSize:40,fontWeight:800,letterSpacing:6,background:`linear-gradient(135deg,${C.goldL},${C.gold})`,WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>JADWAL</div>
          <div style={{fontSize:11,color:C.dim,letterSpacing:2,marginTop:2}}>جدول · UAE WORKFORCE AI</div>
          <div style={{marginTop:10}}><button onClick={()=>setLang(l=>l==="en"?"ar":"en")} style={{padding:"6px 14px",borderRadius:8,border:`1px solid ${C.goldD}`,background:`${C.gold}12`,color:C.gold,cursor:"pointer",fontFamily:"inherit",fontSize:12,fontWeight:700}}>{t.langToggle}</button></div>
        </div>
        <Card glow style={{animation:"pop .42s cubic-bezier(.16,1,.3,1) both"}}>
          <div style={{display:"flex",background:C.bg,borderRadius:11,padding:4,marginBottom:20}}>
            {["login","signup"].map(m=><button key={m} onClick={()=>{setMode(m);setErr("");}} style={{flex:1,padding:"9px",borderRadius:8,border:"none",cursor:"pointer",background:mode===m?`linear-gradient(135deg,${C.gold},${C.goldD})`:"transparent",color:mode===m?"#000":C.sub,fontWeight:700,fontSize:12,fontFamily:"inherit",transition:"all .18s"}}>{m==="login"?t.signIn:t.createAcc}</button>)}
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            {mode==="signup"&&<>
              <Inp label={t.name} value={f.name} onChange={s("name")} placeholder="Ahmed Al Mansouri" req dir={rtl?"rtl":"ltr"}/>
              <Inp label={t.biz} value={f.biz} onChange={s("biz")} placeholder="Adidas — Dubai Mall" req dir={rtl?"rtl":"ltr"}/>
              <Sel label={t.bizType} value={f.bizType} onChange={s("bizType")} options={BTYPES}/>
              <Inp label={t.phone} value={f.phone} onChange={s("phone")} placeholder="+971 55 000 0000" dir="ltr"/>
            </>}
            <Inp label={t.email} value={f.email} onChange={s("email")} type="email" placeholder="you@company.ae" req dir="ltr"/>
            <Inp label={t.password} value={f.pass} onChange={s("pass")} type="password" placeholder="••••••••" req dir="ltr"/>
            {err&&<div style={{color:C.red,fontSize:12,padding:"8px 12px",background:C.redD,borderRadius:8}}>{err}</div>}
            <Btn onClick={submit} disabled={busy} sz="lg" full>{busy?<><div className="spinner"/>{t.processing}</>:`${t.signIn} →`}</Btn>
          </div>
          {mode==="login"&&<div style={{marginTop:12,padding:"10px 13px",background:C.bg,borderRadius:9,fontSize:11,color:C.dim}}>
            <div style={{fontWeight:700,color:C.sub,marginBottom:3}}>🎯 {t.demoAcc}</div>
            demo@jadwal.ae · demo123
          </div>}
        </Card>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════
// DASHBOARD
// ═══════════════════════════════════════════════════════════
function DashPage({t,user,emps,scheds,notifs,pct,fine,setPage,expVisa,warnVisa,lang}){
  const unread=notifs.filter(n=>!n.read).length;
  const latest=scheds[scheds.length-1]||null;
  return <div style={{display:"flex",flexDirection:"column",gap:18}}>
    <Card glow className="fu" style={{background:`linear-gradient(135deg,${C.card},#0e0e22)`,display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:14}}>
      <div>
        <div style={{fontFamily:"'Syne',sans-serif",fontSize:21,fontWeight:800,marginBottom:4}}>{t.welcome}, {user?.name?.split(" ")[0]} 👋</div>
        <div style={{fontSize:12,color:C.sub}}>{user?.biz} · {user?.bizType}</div>
        {fine>0&&<div style={{marginTop:7,fontSize:12,color:C.red,fontWeight:600}}>🚨 AED {fine.toLocaleString()}/month Emiratisation fine risk</div>}
        {expVisa>0&&<div style={{marginTop:4,fontSize:12,color:C.red,fontWeight:600}}>🛂 {expVisa} employee(s) have expired visas</div>}
      </div>
      <div style={{display:"flex",gap:10,flexWrap:"wrap"}}>
        <Btn onClick={()=>setPage("schedule")}>🤖 {t.generate}</Btn>
        <Btn v="outline" onClick={()=>setPage("employees")}>+ {t.addEmp}</Btn>
      </div>
    </Card>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(150px,1fr))",gap:12}}>
      {[
        {n:emps.length,l:t.totalStaff,c:C.blue,icon:"👥"},
        {n:emps.filter(e=>isEmirati(e.nationality)).length,l:t.emiratis,c:pct>=2?C.green:C.orange,icon:"🇦🇪"},
        {n:scheds.length,l:t.schedules,c:C.gold,icon:"🗓"},
        {n:expVisa+warnVisa,l:t.visas,c:expVisa>0?C.red:C.orange,icon:"🛂"},
      ].map((s,i)=><Card key={i} className="fu" style={{animationDelay:`${i*.07}s`,textAlign:"center"}}>
        <div style={{fontSize:26,marginBottom:7}}>{s.icon}</div>
        <div style={{fontFamily:"'Syne',sans-serif",fontSize:26,fontWeight:800,color:s.c}}>{s.n}</div>
        <div style={{fontWeight:700,fontSize:11,marginTop:2}}>{s.l}</div>
      </Card>)}
    </div>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:18}}>
      <Card className="fu" style={{animationDelay:".28s"}}>
        <div style={{fontFamily:"'Syne',sans-serif",fontSize:13,fontWeight:700,marginBottom:14}}>{t.quickActions}</div>
        {[
          {icon:"🤖",label:t.schedule,page:"schedule",c:C.gold},
          {icon:"🏛️",label:t.mohre,page:"mohre",c:C.blue},
          {icon:"💰",label:t.wps,page:"wps",c:C.green},
          {icon:"🛂",label:t.visas,page:"visas",c:C.orange},
        ].map((a,i)=><button key={i} onClick={()=>setPage(a.page)} style={{display:"flex",gap:10,alignItems:"center",padding:"10px 12px",background:C.bg,borderRadius:11,border:`1px solid ${C.border}`,cursor:"pointer",textAlign:"left",transition:"border .15s",fontFamily:"inherit",marginBottom:8,width:"100%"}}
          onMouseEnter={e=>e.currentTarget.style.borderColor=a.c}
          onMouseLeave={e=>e.currentTarget.style.borderColor=C.border}>
          <div style={{width:34,height:34,borderRadius:9,background:`${a.c}18`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,flexShrink:0}}>{a.icon}</div>
          <div style={{fontWeight:700,fontSize:12}}>{a.label}</div>
        </button>)}
      </Card>
      <Card className="fu" style={{animationDelay:".36s"}}>
        <div style={{fontFamily:"'Syne',sans-serif",fontSize:13,fontWeight:700,marginBottom:14}}>{t.teamOverview}</div>
        {emps.length===0?<div style={{textAlign:"center",padding:"24px",color:C.dim,fontSize:12}}>{t.noEmps}</div>:
        emps.slice(0,5).map((e,i)=>{
          const vs=visaStatus(e.visaExpiry);
          return <div key={e.id} style={{display:"flex",gap:9,alignItems:"center",padding:"7px 0",borderBottom:i<Math.min(emps.length,5)-1?`1px solid ${C.border}10`:undefined}}>
            <div style={{width:30,height:30,borderRadius:9,background:`linear-gradient(135deg,${C.goldD},${C.gold}50)`,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:10,color:C.goldL,flexShrink:0}}>{e.name.split(" ").map(w=>w[0]).join("").slice(0,2)}</div>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontWeight:600,fontSize:12,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{lang==="ar"&&e.nameAr?e.nameAr:e.name}</div>
              <div style={{fontSize:10,color:C.dim}}>{e.role}</div>
            </div>
            <Bdg color={isEmirati(e.nationality)?C.green:C.sub}>{e.nationality==="Emirati"?"🇦🇪":e.nationality.slice(0,3)}</Bdg>
            {vs==="expired"&&<Bdg color={C.red}>🛂!</Bdg>}
          </div>;
        })}
      </Card>
    </div>
    {latest&&<Card className="fu" style={{animationDelay:".44s",borderColor:C.green+"40"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:10}}>
        <div>
          <div style={{fontWeight:700,fontSize:13,color:C.green}}>✓ {t.latestSched}</div>
          <div style={{fontSize:11,color:C.dim,marginTop:2}}>{new Date(latest.created).toLocaleDateString("en-AE",{weekday:"long",day:"numeric",month:"long"})} · {latest.data?.length} employees{latest.waSent?" · WhatsApp sent":""}</div>
        </div>
        <Btn v="outline" sz="sm" onClick={()=>setPage("schedule")}>{t.viewSched}</Btn>
      </div>
    </Card>}
  </div>;
}

// ═══════════════════════════════════════════════════════════
// EMPLOYEES WITH EID SCANNER
// ═══════════════════════════════════════════════════════════
function EmpsPage({t,emps,saveE,addToast,lang}){
  const [modal,setModal]=useState(false);
  const [editing,setEditing]=useState(null);
  const [search,setSearch]=useState("");
  const [scanLoading,setScanLoading]=useState(false);
  const [scanResult,setScanResult]=useState("");
  const fileRef=useRef();
  const [f,setF]=useState({name:"",nameAr:"",role:"Sales Associate",phone:"",nationality:"Emirati",eid:"",maxHours:40,visaExpiry:"",salary:0,joinDate:""});
  const sf=k=>v=>setF(p=>({...p,[k]:v}));
  const active=emps.filter(e=>e.active);
  const filtered=emps.filter(e=>e.name.toLowerCase().includes(search.toLowerCase())||e.role.toLowerCase().includes(search.toLowerCase())||(e.nameAr&&e.nameAr.includes(search)));
  const emiratis=active.filter(e=>isEmirati(e.nationality)).length;
  const pct=active.length?Math.round(emiratis/active.length*100):0;
  const openAdd=()=>{setEditing(null);setF({name:"",nameAr:"",role:"Sales Associate",phone:"",nationality:"Emirati",eid:"",maxHours:40,visaExpiry:"",salary:0,joinDate:new Date().toISOString().slice(0,10)});setScanResult("");setModal(true);};
  const openEdit=e=>{setEditing(e.id);setF({...e});setScanResult("");setModal(true);};
  const save=()=>{
    if(!f.name||!f.phone){addToast("Name and phone required","error");return;}
    if(editing){
      saveE(emps.map(e=>e.id===editing?{...e,...f}:e));
      addToast(lang==="en"?"Employee updated ✓":"تم تحديث الموظف ✓");
    } else {
      // Auto-create HR profile with empty docs + onboarding checklist on new employee
      const newEmp={
        ...f, id:uid(), active:true,
        docs:{passport:false,eid:false,visa:false,contract:false,medical:false},
        onboarding:{
          contractSigned:false,
          mohreApplied:false,
          contractRegistered:false,
          medicalDone:false,
          wpsActivated:false,
          emiratesIDIssued:false,
          insuranceAdded:false,
        },
        hrStatus:"pending", // pending | ready | blocked
        hrCreatedAt: new Date().toISOString(),
      };
      saveE([...emps, newEmp]);
      addToast(lang==="en"?"Employee added — HR checklist auto-started ✓":"تمت إضافة الموظف — بدأ سير عمل الموارد البشرية تلقائياً ✓");
    }
    setModal(false);
  };
  const toggle=id=>{saveE(emps.map(e=>e.id===id?{...e,active:!e.active}:e));};
  const remove=id=>{if(window.confirm("Remove?"))saveE(emps.filter(e=>e.id!==id));};
  const simulateScan=async()=>{
    setScanLoading(true);setScanResult("");
    await new Promise(r=>setTimeout(r,1800));
    const fake="784-"+Math.floor(1985+Math.random()*15)+"-"+Math.floor(1000000+Math.random()*9000000)+"-"+Math.floor(1+Math.random()*9);
    setScanResult(fake);setF(p=>({...p,eid:fake,nationality:fake.startsWith("784")?"Emirati":p.nationality}));
    setScanLoading(false);addToast(lang==="en"?"Emirates ID scanned ✓":"تم مسح الهوية ✓");
  };

  return <div style={{display:"flex",flexDirection:"column",gap:16}}>
    <div className="fu" style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:10}}>
      <div><div style={{fontFamily:"'Syne',sans-serif",fontSize:18,fontWeight:700}}>{t.employees}</div><div style={{fontSize:11,color:C.dim}}>{active.length} active · {emiratis} Emiratis ({pct}%)</div></div>
      <div style={{display:"flex",gap:9}}>
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder={t.searchPlaceholder} style={{background:C.card,border:`1.5px solid ${C.border}`,color:C.text,borderRadius:9,padding:"8px 12px",fontSize:12,outline:"none",fontFamily:"inherit",width:180}}/>
        <Btn onClick={openAdd}>+ {t.addEmp}</Btn>
      </div>
    </div>
    <Card className="fu" style={{animationDelay:".08s"}}>
      <div style={{display:"flex",justifyContent:"space-between",marginBottom:8,flexWrap:"wrap",gap:6}}>
        <div style={{fontWeight:700,fontSize:13}}>{t.emiratisProgress}</div>
        <div style={{display:"flex",gap:7}}><Bdg color={C.green}>{emiratis}</Bdg><Bdg color={pct>=2?C.green:C.red}>{pct}%</Bdg><Bdg color={C.orange}>{t.required}</Bdg></div>
      </div>
      <div style={{background:C.bg,borderRadius:7,height:10,overflow:"hidden"}}><div style={{height:"100%",borderRadius:7,transition:"width 1s",background:`linear-gradient(90deg,${C.green},${C.goldL})`,width:`${Math.min(pct,100)}%`}}/></div>
    </Card>
    {filtered.length===0&&<div style={{textAlign:"center",padding:"36px",color:C.dim}}>{t.noEmps}</div>}
    {filtered.map((emp,i)=>{
      const vs=visaStatus(emp.visaExpiry); const vd=visaDays(emp.visaExpiry);
      const ps=probationStatus(emp.joinDate); const pl=probationDaysLeft(emp.joinDate);
      return <Card key={emp.id} className="fu" style={{animationDelay:`${i*.04}s`,opacity:emp.active?1:.5,border:`1.5px solid ${vs==="expired"?C.red+"40":ps==="active"?C.purple+"40":isEmirati(emp.nationality)?C.green+"28":C.border}`}}>
        <div style={{display:"flex",gap:12,alignItems:"center",flexWrap:"wrap"}}>
          <div style={{width:44,height:44,borderRadius:12,background:`linear-gradient(135deg,${C.goldD},${C.gold}55)`,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:13,color:C.goldL,flexShrink:0}}>{emp.name.split(" ").map(w=>w[0]).join("").slice(0,2)}</div>
          <div style={{flex:1,minWidth:160}}>
            <div style={{fontWeight:700,fontSize:14}}>{lang==="ar"&&emp.nameAr?emp.nameAr:emp.name}</div>
            <div style={{fontSize:11,color:C.gold}}>{emp.role}</div>
            <div style={{fontSize:10,color:C.dim,marginTop:1}}>📱 {emp.phone}{emp.eid?` · ${emp.eid}`:""}</div>
            {emp.visaExpiry&&<div style={{fontSize:10,marginTop:1,color:vs==="expired"?C.red:vs==="critical"?C.orange:C.dim}}>🛂 {vs==="expired"?"EXPIRED":vs==="critical"?`${vd}d left`:vs==="warning"?`${vd}d`:emp.visaExpiry}</div>}
            {ps==="active"&&<div style={{fontSize:10,marginTop:2,color:C.purple,fontWeight:600}}>🆕 Probation: {pl} days left · ends {formatProbationEnd(emp.joinDate)}</div>}
            {ps==="completed"&&<div style={{fontSize:10,marginTop:2,color:C.green}}>✓ Probation completed · joined {emp.joinDate}</div>}
          </div>
          <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
            <Bdg color={isEmirati(emp.nationality)?C.green:C.sub}>{emp.nationality==="Emirati"?"🇦🇪 Emirati":emp.nationality}</Bdg>
            {emp.salary>0&&<Bdg color={C.blue}>AED {emp.salary.toLocaleString()}</Bdg>}
            {ps==="active"&&<Bdg color={C.purple}>🆕 Probation</Bdg>}
            {vs==="expired"&&<Bdg color={C.red}>🛂 Expired</Bdg>}
          </div>
          <div style={{display:"flex",gap:7}}>
            <Btn onClick={()=>openEdit(emp)} v="ghost" sz="sm">{t.save.split(" ")[0]}</Btn>
            <Btn onClick={()=>toggle(emp.id)} v={emp.active?"red":"green"} sz="sm">{emp.active?"Off":"On"}</Btn>
            <Btn onClick={()=>remove(emp.id)} v="red" sz="sm">✕</Btn>
          </div>
        </div>
      </Card>;
    })}
    {modal&&<Modal title={editing?t.save:t.addEmp} onClose={()=>setModal(false)} w={560}>
      <div style={{background:C.bg,borderRadius:13,padding:16,marginBottom:16,border:`1.5px solid ${C.goldD}40`}}>
        <div style={{fontWeight:700,fontSize:13,color:C.gold,marginBottom:8}}>🤖 {t.eidScanTitle||"AI Emirates ID Scanner"}</div>
        <div style={{fontSize:11,color:C.dim,marginBottom:10}}>{t.scanDesc}</div>
        <input type="file" ref={fileRef} accept="image/*" style={{display:"none"}} onChange={e=>e.target.files[0]&&simulateScan()}/>
        <Btn onClick={()=>{fileRef.current?.click();simulateScan();}} v="outline" sz="sm" disabled={scanLoading}>
          {scanLoading?<><div className="spinner"/>{t.processing}</>:t.scanEID}
        </Btn>
        {scanResult&&<div style={{marginTop:10,padding:"8px 12px",background:C.greenD,border:`1px solid ${C.green}40`,borderRadius:8,fontSize:11,color:C.green}}>{t.eidFound}: <strong>{scanResult}</strong> — {t.eidEmirati}</div>}
        <div style={{marginTop:10,fontSize:10,color:C.dim}}>─── {lang==="en"?"Or enter manually":"أو أدخل يدوياً"} ───</div>
      </div>
      <div style={{display:"flex",flexDirection:"column",gap:11}}>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <Inp label={t.name} value={f.name} onChange={sf("name")} placeholder="Ahmed Al Mansouri" req/>
          <Inp label={t.nameAr} value={f.nameAr} onChange={sf("nameAr")} placeholder="أحمد المنصوري" dir="rtl"/>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <Sel label={t.role} value={f.role} onChange={sf("role")} options={ROLES}/>
          <Sel label={t.nationality} value={f.nationality} onChange={sf("nationality")} options={NATS}/>
        </div>
        <Inp label={t.phone} value={f.phone} onChange={sf("phone")} placeholder="+971 50 000 0000" req dir="ltr"/>
        <Inp label={t.eid} value={f.eid} onChange={v=>{sf("eid")(v);if(v.startsWith("784"))sf("nationality")("Emirati");}} placeholder="784-1990-1234567-1" note="784 prefix = UAE National auto-detected" dir="ltr"/>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <Inp label={t.maxHours} value={String(f.maxHours)} onChange={v=>sf("maxHours")(Number(v)||40)} type="number"/>
          <Inp label={t.salary} value={String(f.salary||"")} onChange={v=>sf("salary")(Number(v)||0)} type="number"/>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <Inp label={t.visaExpiry} value={f.visaExpiry} onChange={sf("visaExpiry")} type="date"/>
          <Inp label={t.joinDate||"Join Date"} value={f.joinDate} onChange={sf("joinDate")} type="date" note="Sets 6-month probation period"/>
        </div>
        {f.joinDate&&probationStatus(f.joinDate)==="active"&&<div style={{padding:"10px 14px",background:`${C.purple}12`,border:`1px solid ${C.purple}40`,borderRadius:10,fontSize:12}}>
          <div style={{fontWeight:700,color:C.purple,marginBottom:4}}>🆕 Probation Period — UAE Federal Decree Law 33/2021</div>
          <div style={{color:C.sub,lineHeight:1.7}}>This employee is on a 6-month probation. Probation ends: <strong style={{color:C.purple}}>{formatProbationEnd(f.joinDate)}</strong><br/>During probation: 14-day notice to terminate · No end-of-service gratuity if employee resigns · Cannot be re-probated.</div>
        </div>}
        {f.joinDate&&probationStatus(f.joinDate)==="completed"&&<div style={{padding:"8px 12px",background:C.greenD,border:`1px solid ${C.green}40`,borderRadius:8,fontSize:11,color:C.green}}>✓ Probation completed — Full employment rights apply</div>}
        {f.eid&&f.eid.startsWith("784")&&<div style={{padding:"8px 12px",background:C.greenD,border:`1px solid ${C.green}40`,borderRadius:8,fontSize:11,color:C.green}}>✓ Emirati detected from Emirates ID</div>}
        <div style={{display:"flex",gap:9,justifyContent:"flex-end"}}>
          <Btn v="ghost" onClick={()=>setModal(false)}>{t.cancel}</Btn>
          <Btn onClick={save}>{editing?t.save:t.addEmp}</Btn>
        </div>
      </div>
    </Modal>}
  </div>;
}

// ═══════════════════════════════════════════════════════════
// SCHEDULE
// ═══════════════════════════════════════════════════════════
function SchedPage({t,emps,scheds,saveS,notifs,saveN,addToast,lang,summer}){
  const [loading,setLoading]=useState(false);
  const [aiMsg,setAiMsg]=useState("");
  const [current,setCurrent]=useState(scheds[scheds.length-1]||null);
  const [waSending,setWaSending]=useState(false);
  const [waProgress,setWaProgress]=useState(0);
  const [bizType,setBizType]=useState("Retail Store");

  const shiftColor=s=>{
    if(!s||s.includes("OFF")||s==="—") return {bg:"#131320",c:C.dim,b:C.border};
    if(s.includes("7AM")||s.includes("Morning")) return {bg:C.orangeD,c:C.orange,b:C.orange+"40"};
    if(s.includes("3PM")||s.includes("Afternoon")) return {bg:C.blueD,c:C.blue,b:C.blue+"40"};
    return {bg:"#1a0a2e",c:C.purple,b:C.purple+"40"};
  };

  const generate=async()=>{
    if(!emps.length){addToast(lang==="en"?"Add employees first":"أضف موظفين أولاً","error");return;}

    // HR Alert — never blocks, just informs supervisor and HR simultaneously
    const hrIssues = emps.filter(e=>{
      const docs=e.docs||{};
      const missingDocs=!docs.passport||!docs.visa||!docs.contract;
      const pd=e.permitExpiry?Math.round((new Date(e.permitExpiry)-new Date())/86400000):null;
      const permitExpired=pd!==null&&pd<0;
      return missingDocs||permitExpired;
    });
    if(hrIssues.length>0){
      const names=hrIssues.map(e=>e.name.split(" ")[0]).join(", ");
      addToast(`⚠ HR Alert: ${names} — missing docs or expired permit. Schedule generating anyway.`,"warning");
    }

    setLoading(true);setCurrent(null);setWaProgress(0);
    const steps=lang==="en"?
      ["Analyzing availability...","Checking UAE labor law...","Verifying Emiratisation...","Applying midday break rules...","Generating with Claude AI..."]:
      ["تحليل التوافر...","التحقق من قانون العمل الإماراتي...","التحقق من التوطين...","تطبيق قواعد استراحة الظهيرة...","الإنشاء بالذكاء الاصطناعي..."];
    for(const s of steps){setAiMsg(s);await new Promise(r=>setTimeout(r,580));}

    const prompt=`You are a UAE workforce scheduling AI for a ${bizType}.
Employees:
${emps.map(e=>`- ${e.name} | ${e.role} | ${e.nationality} | Max ${e.maxHours}hrs/week`).join("\n")}
Rules:
- Max 8 hours per shift
- Max 5 working days per week
- At least 1 supervisor per day
- Prioritize Emirati staff on visible/customer-facing shifts for Emiratisation
- Friday is a short day (Morning 7AM-12PM only if scheduled)
${summer?"- MIDDAY BREAK LAW ACTIVE: No outdoor roles (Security, Cleaning, Warehouse, Driver) can have shifts that include 12:30PM-3:00PM (June-September UAE law Article 66)":""}
Return ONLY valid JSON array, no markdown, no extra text:
[{"employee":"Full Name","role":"Role","emirati":true,"schedule":{"Sunday":"Morning 7AM-3PM or Afternoon 3PM-11PM or OFF","Monday":"...","Tuesday":"...","Wednesday":"...","Thursday":"...","Friday":"Morning 7AM-12PM or OFF"},"totalHours":40,"whatsappMsg":"Friendly personalized WhatsApp message in English mentioning their specific shifts for the week, signed JADWAL 🗓"}]`;

    try{
      const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1000,messages:[{role:"user",content:prompt}]})});
      const data=await res.json();
      const text=data.content.map(c=>c.text||"").join("").replace(/```json|```/g,"").trim();
      const rows=JSON.parse(text);
      const sched={id:uid(),created:new Date().toISOString(),data:rows,published:false,waSent:false,bizType};
      saveS([...scheds,sched]);setCurrent(sched);
      addToast(lang==="en"?"AI schedule generated ✓":"تم إنشاء الجدول بالذكاء الاصطناعي ✓");
    }catch{
      const fallback=emps.map((emp,i)=>({employee:emp.name,role:emp.role,emirati:isEmirati(emp.nationality),
        schedule:{Sunday:i%3===0?"OFF":"Morning 7AM-3PM",Monday:"Morning 7AM-3PM",Tuesday:i%4===0?"OFF":"Afternoon 3PM-11PM",Wednesday:"Morning 7AM-3PM",Thursday:i%5===0?"OFF":"Afternoon 3PM-11PM",Friday:"Morning 7AM-12PM"},
        totalHours:40,whatsappMsg:`Hi ${emp.name.split(" ")[0]}! 👋 Your JADWAL schedule for next week is ready. Check your shifts in the app and let us know if you have any questions. Have a great week! 🗓 — JADWAL`}));
      const sched={id:uid(),created:new Date().toISOString(),data:fallback,published:false,waSent:false,bizType};
      saveS([...scheds,sched]);setCurrent(sched);
      addToast(lang==="en"?"Schedule generated ✓":"تم إنشاء الجدول ✓");
    }
    setLoading(false);setAiMsg("");
  };

  const publish=()=>{
    if(!current)return;
    const u=scheds.map(s=>s.id===current.id?{...s,published:true}:s);
    saveS(u);setCurrent({...current,published:true});
    addToast(lang==="en"?"Schedule published ✓":"تم نشر الجدول ✓");
  };

  const sendWA=async()=>{
    if(!current)return;
    setWaSending(true);setWaProgress(0);
    const newN=[...notifs];
    for(let i=0;i<current.data.length;i++){
      await new Promise(r=>setTimeout(r,420));
      const row=current.data[i];
      const emp=emps.find(e=>e.name===row.employee);
      newN.push({id:uid(),type:"schedule",employee:row.employee,phone:emp?.phone||"",message:row.whatsappMsg,time:now(),read:false,delivered:true,scheduleId:current.id});
      setWaProgress(i+1);
    }
    // Owner summary
    newN.push({id:uid(),type:"summary",employee:"You (Owner)",phone:"+971554660881",
      message:`✅ JADWAL Schedule Published!\n\nYour schedule for the week has been published.\n📊 ${current.data.length} employees notified\n🇦🇪 Emiratis: ${current.data.filter(r=>r.emirati).length}\n⚖️ Compliance: Active\n\nPowered by JADWAL AI 🤖`,
      time:now(),read:false,delivered:true,isOwner:true,scheduleId:current.id});
    saveN(newN);
    const u=scheds.map(s=>s.id===current.id?{...s,waSent:true}:s);
    saveS(u);setCurrent({...current,waSent:true});
    setWaSending(false);
    addToast(`${current.data.length+1} ${lang==="en"?"WhatsApp messages sent ✓":"رسائل واتساب أُرسلت ✓"}`);
  };

  return <div style={{display:"flex",flexDirection:"column",gap:16}}>
    {summer&&<Card style={{background:C.orangeD,border:`1.5px solid ${C.orange}50`,padding:"14px 18px"}}>
      <div style={{display:"flex",gap:12,alignItems:"center"}}>
        <span style={{fontSize:26}}>☀️</span>
        <div>
          <div style={{fontWeight:700,color:C.orange,fontSize:13}}>🚫 Midday Break Law — AUTO-BLOCK ACTIVE</div>
          <div style={{fontSize:11,color:C.sub,marginTop:3}}>UAE Article 66: No outdoor work 12:30PM–3PM (June–September). Applied automatically to this AI schedule for Security, Warehouse, Cleaning, Driver roles.</div>
        </div>
      </div>
    </Card>}

    <Card glow className="fu">
      <div style={{display:"flex",gap:12,alignItems:"flex-start",marginBottom:14}}>
        <div style={{width:48,height:48,borderRadius:13,background:`linear-gradient(135deg,${C.gold},${C.goldD})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:24,flexShrink:0}}>🤖</div>
        <div>
          <div style={{fontFamily:"'Syne',sans-serif",fontSize:17,fontWeight:700}}>{t.schedule}</div>
          <div style={{fontSize:11,color:C.sub}}>Claude AI · UAE Labor Law · Emiratisation-aware{summer?" · Midday Block":""}</div>
        </div>
      </div>
      <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"flex-end",marginBottom:14}}>
        <Sel label={lang==="en"?"Business Type":"نوع النشاط"} value={bizType} onChange={setBizType} options={BTYPES}/>
        <div style={{display:"flex",gap:9,alignItems:"flex-end",flexWrap:"wrap"}}>
          <Btn onClick={generate} disabled={loading}>{loading?<><div className="spinner"/>{t.generating}</>:<>✦ {t.generate}</>}</Btn>
          {current&&!current.published&&<Btn v="green" onClick={publish}>📢 {t.publish}</Btn>}
          {current?.published&&!current?.waSent&&<Btn v="wa" onClick={sendWA} disabled={waSending}>{waSending?<><div className="spinner"/>Sending {waProgress}/{current.data.length}...</>:<>💬 {t.sendWA}</>}</Btn>}
          {current?.waSent&&<Bdg color={C.wa}>✓ Sent</Bdg>}
          {current?.published&&<Bdg color={C.green}>✓ Published</Bdg>}
        </div>
      </div>
      {loading&&<div style={{padding:"12px 16px",background:C.bg,borderRadius:10,display:"flex",gap:10,alignItems:"center",border:`1px solid ${C.goldD}35`,marginBottom:12}}>
        <div className="spinner"/><span style={{fontSize:12,color:C.gold}}>{aiMsg}</span>
      </div>}
      {!current&&!loading&&<div style={{textAlign:"center",padding:"36px",color:C.dim}}>
        <div style={{fontSize:40,marginBottom:10}} className="pulse">🗓</div>
        <div style={{fontSize:13}}>{t.noSched}</div>
      </div>}
    </Card>

    {current?.data&&<Card className="fu" style={{animationDelay:".1s"}}>
      <div style={{fontFamily:"'Syne',sans-serif",fontSize:14,fontWeight:700,marginBottom:4}}>{lang==="en"?"Weekly Schedule":"الجدول الأسبوعي"}</div>
      <div style={{fontSize:11,color:C.dim,marginBottom:14}}>{new Date(current.created).toLocaleDateString("en-AE",{day:"numeric",month:"short",year:"numeric"})} · {current.data.length} {lang==="en"?"employees":"موظفين"} · {current.bizType}</div>
      <div style={{overflowX:"auto"}}>
        <table style={{width:"100%",borderCollapse:"collapse",fontSize:11}}>
          <thead><tr>{[lang==="en"?"Employee":"الموظف",lang==="en"?"Role":"المسمى","Sun","Mon","Tue","Wed","Thu","Fri","Hrs","Type"].map(h=><th key={h} style={{textAlign:"left",padding:"8px 9px",color:C.sub,letterSpacing:.5,textTransform:"uppercase",borderBottom:`1px solid ${C.border}`,whiteSpace:"nowrap",fontWeight:700,fontSize:10}}>{h}</th>)}</tr></thead>
          <tbody>{current.data.map((row,i)=>(
            <tr key={i} style={{borderBottom:`1px solid ${C.border}08`}}
              onMouseEnter={e=>e.currentTarget.style.background=C.cardHov}
              onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
              <td style={{padding:"9px",fontWeight:700,whiteSpace:"nowrap",fontSize:12}}>{row.employee}</td>
              <td style={{padding:"9px",color:C.gold,whiteSpace:"nowrap",fontSize:11}}>{row.role}</td>
              {DAYS.map(d=>{
                const s=row.schedule?.[d]||"OFF";
                const{bg,c,b}=shiftColor(s);
                return <td key={d} style={{padding:"9px 7px"}}>
                  <span style={{background:bg,color:c,border:`1px solid ${b}`,borderRadius:5,padding:"2px 7px",whiteSpace:"nowrap",fontSize:10,fontWeight:600}}>
                    {s.includes("OFF")||s==="—"?"—":s.includes("7AM")||s.includes("Morning")?"☀️ AM":s.includes("3PM")||s.includes("Afternoon")?"🌤 PM":"🌙"}
                  </span>
                </td>;
              })}
              <td style={{padding:"9px",color:C.dim,fontSize:11}}>{row.totalHours||40}h</td>
              <td style={{padding:"9px"}}>
                {(()=>{
                  const emp=emps.find(e=>e.name===row.employee);
                  const docs=emp?.docs||{};
                  const hrOk=docs.passport&&docs.visa&&docs.contract;
                  const pd=emp?.permitExpiry?Math.round((new Date(emp.permitExpiry)-new Date())/86400000):null;
                  const permitOk=pd===null||pd>0;
                  if(!hrOk||!permitOk) return <Bdg color={C.red}>⚠ HR</Bdg>;
                  return <Bdg color={row.emirati?C.green:C.sub}>{row.emirati?"🇦🇪":"✓"}</Bdg>;
                })()}
              </td>
            </tr>
          ))}</tbody>
        </table>
      </div>
    </Card>}

    {scheds.length>1&&<Card className="fu" style={{animationDelay:".2s"}}>
      <div style={{fontFamily:"'Syne',sans-serif",fontSize:13,fontWeight:700,marginBottom:12}}>{lang==="en"?"Schedule History":"سجل الجداول"}</div>
      {[...scheds].reverse().map((s,i)=><div key={s.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"9px 12px",background:C.bg,borderRadius:9,marginBottom:7,border:`1px solid ${i===0?C.goldD:C.border}`}}>
        <div>
          <div style={{fontWeight:600,fontSize:12}}>{new Date(s.created).toLocaleDateString("en-AE",{weekday:"short",day:"numeric",month:"short"})}</div>
          <div style={{fontSize:10,color:C.dim}}>{s.data?.length||0} emps · {s.bizType||""}</div>
        </div>
        <div style={{display:"flex",gap:6}}>
          {s.published&&<Bdg color={C.green}>Published</Bdg>}
          {s.waSent&&<Bdg color={C.wa}>WA Sent</Bdg>}
          {i===0&&<Bdg color={C.gold}>Latest</Bdg>}
          <Btn v="ghost" sz="sm" onClick={()=>setCurrent(s)}>View</Btn>
        </div>
      </div>)}
    </Card>}
  </div>;
}

// ═══════════════════════════════════════════════════════════
// WHATSAPP
// ═══════════════════════════════════════════════════════════
function WAPage({t,notifs,saveN,emps}){
  const markRead=()=>saveN(notifs.map(n=>({...n,read:true})));
  return <div style={{display:"flex",flexDirection:"column",gap:16}}>
    <div className="fu" style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:10}}>
      <div><div style={{fontFamily:"'Syne',sans-serif",fontSize:18,fontWeight:700}}>{t.whatsapp}</div><div style={{fontSize:11,color:C.dim}}>{notifs.length} messages · {notifs.filter(n=>!n.read).length} unread</div></div>
      {notifs.length>0&&<div style={{display:"flex",gap:8}}><Btn v="ghost" sz="sm" onClick={markRead}>{t.markRead}</Btn><Btn v="red" sz="sm" onClick={()=>saveN([])}>{t.clearAll}</Btn></div>}
    </div>
    {notifs.length===0?<Card style={{textAlign:"center",padding:"48px"}}>
      <div style={{fontSize:44,marginBottom:12}} className="pulse">💬</div>
      <div style={{fontSize:12,color:C.dim}}>{t.noMsgs}</div>
    </Card>:<div style={{display:"flex",flexDirection:"column",gap:10}}>
      {[...notifs].reverse().map((msg,i)=><div key={msg.id} className="fu" style={{animationDelay:`${i*.05}s`,background:msg.isOwner?`linear-gradient(135deg,${C.card},#0a1a0a)`:C.card,border:`1.5px solid ${msg.read?C.border:msg.isOwner?C.wa+"45":C.gold+"35"}`,borderRadius:16,borderBottomLeftRadius:4,padding:"14px 18px",maxWidth:500}}>
        <div style={{display:"flex",justifyContent:"space-between",marginBottom:7,flexWrap:"wrap",gap:4}}>
          <span style={{fontWeight:700,fontSize:12,color:msg.isOwner?C.wa:C.gold}}>{msg.isOwner?"👤 ":""}{msg.employee}</span>
          <span style={{fontSize:10,color:C.dim}}>{msg.phone} · {msg.time}</span>
        </div>
        <div style={{fontSize:12,lineHeight:1.7,color:C.text,whiteSpace:"pre-line"}}>{msg.message}</div>
        <div style={{fontSize:10,color:C.wa,marginTop:6,textAlign:"right",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <span>{!msg.read&&<Bdg color={C.gold}>New</Bdg>}</span>
          <span>✓✓ Delivered</span>
        </div>
      </div>)}
    </div>}
  </div>;
}

// ═══════════════════════════════════════════════════════════
// COMPLIANCE
// ═══════════════════════════════════════════════════════════
function CompliancePage({t,emps,pct,fine}){
  const emiratis=emps.filter(e=>isEmirati(e.nationality)).length;
  const gap=Math.max(0,Math.ceil(emps.length*.1)-emiratis);
  return <div style={{display:"flex",flexDirection:"column",gap:16}}>
    <Card glow className="fu" style={{borderColor:pct>=2?C.green:C.red}}>
      <div style={{display:"flex",justifyContent:"space-between",marginBottom:12,flexWrap:"wrap",gap:8}}>
        <div><div style={{fontFamily:"'Syne',sans-serif",fontSize:17,fontWeight:700}}>{t.complianceCenter}</div><div style={{fontSize:11,color:C.dim}}>UAE 2026 Requirements</div></div>
        <Bdg color={pct>=2?C.green:C.red}>{pct>=2?"✓ Compliant":"⚠ At Risk"}</Bdg>
      </div>
      <div style={{background:C.bg,borderRadius:7,height:14,overflow:"hidden",marginBottom:8}}>
        <div style={{height:"100%",borderRadius:7,transition:"width 1.2s",background:`linear-gradient(90deg,${C.green},${C.goldL})`,width:`${Math.min(pct,100)}%`}}/>
      </div>
      <div style={{display:"flex",justifyContent:"space-between",fontSize:10,color:C.dim}}><span>0%</span><span style={{color:C.orange}}>2% — 2026</span><span style={{color:C.blue}}>5% — 2028</span><span style={{color:C.green}}>10% — 2030</span></div>
    </Card>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(155px,1fr))",gap:12}}>
      {[{l:"Total Staff",v:emps.length,c:C.text,icon:"👥"},{l:"Emiratis",v:emiratis,c:C.green,icon:"🇦🇪"},{l:"Gap to 2030",v:gap,c:gap>0?C.red:C.green,icon:"📋"},{l:"Fine/Month",v:`AED ${fine.toLocaleString()}`,c:fine>0?C.red:C.green,icon:"💰"}].map((s,i)=><Card key={i} className="fu" style={{animationDelay:`${i*.06}s`,textAlign:"center"}}>
        <div style={{fontSize:22,marginBottom:6}}>{s.icon}</div>
        <div style={{fontFamily:"'Syne',sans-serif",fontSize:20,fontWeight:800,color:s.c}}>{s.v}</div>
        <div style={{fontSize:11,color:C.dim,marginTop:2}}>{s.l}</div>
      </Card>)}
    </div>
    <Card className="fu" style={{animationDelay:".4s",border:`1.5px solid ${C.green}28`}}>
      <div style={{fontFamily:"'Syne',sans-serif",fontSize:13,fontWeight:700,marginBottom:12,color:C.green}}>UAE Labor Laws Auto-Enforced in Every Schedule</div>
      {[
        {c:C.gold,law:"Emiratisation / NAFIS 2026",d:"AED 7,000/month per missing Emirati. Tracks quota in real time."},
        {c:C.blue,law:"WPS 2.0 — July 2026",d:"Wage Protection System SIF file export. Mandatory July 2026."},
        {c:C.orange,law:"Midday Break — Article 66",d:"No outdoor work 12:30PM–3PM Jun–Sep. Auto-blocked in schedules."},
        {c:C.green,law:"Federal Decree Law 33/2021",d:"Max 8hrs/shift, 48hrs/week. Ramadan reduced hours. All enforced."},
        {c:C.red,law:"Visa / Work Permit Tracking",d:"90-day advance alerts before any employee visa expires."},
      ].map((r,i)=><div key={i} style={{display:"flex",gap:10,padding:"8px 0",borderBottom:i<4?`1px solid ${C.border}10`:undefined}}>
        <div style={{width:8,height:8,borderRadius:"50%",background:r.c,marginTop:5,flexShrink:0}}/>
        <div><div style={{fontWeight:600,fontSize:12,color:r.c}}>{r.law}</div><div style={{fontSize:11,color:C.dim,marginTop:1}}>{r.d}</div></div>
      </div>)}
    </Card>
  </div>;
}

// ═══════════════════════════════════════════════════════════
// MOHRE & NAFIS
// ═══════════════════════════════════════════════════════════
function MOHREPage({t,emps,pct,fine}){
  const emiratis=emps.filter(e=>isEmirati(e.nationality)).length;
  const need26=Math.max(0,Math.ceil(emps.length*0.02)-emiratis);
  const need30=Math.max(0,Math.ceil(emps.length*0.10)-emiratis);
  const cls=pct>=5?"A":pct>=2?"B":"C";
  const clsColor={A:C.green,B:C.orange,C:C.red};
  return <div style={{display:"flex",flexDirection:"column",gap:16}}>
    <Card glow className="fu">
      <div style={{fontFamily:"'Syne',sans-serif",fontSize:17,fontWeight:700,marginBottom:4}}>{t.mohre}</div>
      <div style={{fontSize:11,color:C.dim,marginBottom:16}}>Ministry of Human Resources & Emiratisation · NAFIS Program Live Tracking</div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(175px,1fr))",gap:12}}>
        {[
          {icon:"🏛️",l:t.mohreClass,v:`Class ${cls}`,d:"Based on Emiratisation",c:clsColor[cls]},
          {icon:"📋",l:t.nafisTarget,v:`${Math.ceil(emps.length*0.02)} needed`,d:need26===0?"✓ Met":need26+" more needed",c:need26===0?C.green:C.orange},
          {icon:"🎯",l:t.nafisTarget30,v:`${Math.ceil(emps.length*0.10)} needed`,d:need30===0?"✓ On track":need30+" more needed",c:need30===0?C.green:C.red},
          {icon:"💰",l:t.fineRisk,v:`AED ${fine.toLocaleString()}`,d:fine>0?"Pay or hire Emiratis":"No fine risk",c:fine>0?C.red:C.green},
          {icon:"📊",l:"Current Rate",v:`${pct}%`,d:"vs 2% required",c:pct>=2?C.green:C.red},
          {icon:"🔄",l:"WPS Status",v:"Active",d:"Salary tracking",c:C.green},
        ].map((s,i)=><Card key={i} className="fu" style={{animationDelay:`${i*.06}s`}}>
          <div style={{fontSize:22,marginBottom:7}}>{s.icon}</div>
          <div style={{fontSize:10,color:C.dim}}>{s.l}</div>
          <div style={{fontFamily:"'Syne',sans-serif",fontSize:17,fontWeight:800,color:s.c,margin:"4px 0"}}>{s.v}</div>
          <div style={{fontSize:10,color:s.d.includes("✓")?C.green:C.dim}}>{s.d}</div>
        </Card>)}
      </div>
    </Card>
    <Card className="fu" style={{animationDelay:".3s"}}>
      <div style={{fontFamily:"'Syne',sans-serif",fontSize:13,fontWeight:700,marginBottom:14,color:C.goldL}}>NAFIS Milestone Timeline 2023–2030</div>
      {[
        {y:"2023",p:"1%",s:"past"},{y:"2024",p:"2%",s:"past"},{y:"2025",p:"3%",s:"past"},
        {y:"2026",p:"2% min + 1% growth",s:"current",fine:"AED 7,000/mo"},
        {y:"2027",p:"4%",s:"upcoming"},{y:"2028",p:"5%",s:"upcoming"},
        {y:"2030",p:"10%",s:"upcoming",fine:"AED 7,000+/mo"},
      ].map((m,i)=><div key={i} style={{display:"flex",gap:12,padding:"9px 12px",background:m.s==="current"?`${C.gold}10`:C.bg,borderRadius:10,marginBottom:6,border:`1px solid ${m.s==="current"?C.goldD:C.border}`,alignItems:"center"}}>
        <Bdg color={m.s==="past"?C.dim:m.s==="current"?C.gold:C.blue}>{m.y}</Bdg>
        <div style={{flex:1,fontSize:12,fontWeight:m.s==="current"?700:400}}>{m.p}</div>
        {m.fine&&<Bdg color={C.red}>{m.fine}</Bdg>}
        {m.s==="current"&&<Bdg color={C.gold}>NOW</Bdg>}
        {m.s==="past"&&<Bdg color={C.dim}>Past</Bdg>}
      </div>)}
    </Card>
  </div>;
}

// ═══════════════════════════════════════════════════════════
// WPS EXPORT
// ═══════════════════════════════════════════════════════════
function WPSPage({t,emps,addToast}){
  const [month,setMonth]=useState(new Date().toISOString().slice(0,7));
  const [preview,setPreview]=useState("");
  const activeEmps=emps.filter(e=>e.active);
  const withSalary=activeEmps.filter(e=>e.salary>0);
  const total=withSalary.reduce((a,e)=>a+(e.salary||0),0);

  const generate=()=>{
    if(!withSalary.length){addToast("Add salary data to employees first","error");return;}
    const[yr,mn]=month.split("-");
    let sif=`H|${yr}${mn}01|JADWAL001|AED|${withSalary.length}|${total.toFixed(2)}\n`;
    withSalary.forEach(e=>{sif+=`D|${e.eid||"N/A"}|${e.name}|${(e.salary||0).toFixed(2)}|${(e.salary||0).toFixed(2)}|00.00|00.00|${yr}${mn}25|1\n`;});
    sif+=`T|${withSalary.length}|${total.toFixed(2)}`;
    setPreview(sif);addToast("WPS SIF file generated ✓");
  };

  const download=()=>{
    const blob=new Blob([preview],{type:"text/plain"});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a");a.href=url;a.download=`JADWAL_WPS_${month.replace("-","")}.sif`;a.click();
    URL.revokeObjectURL(url);addToast("WPS file downloaded ✓");
  };

  return <div style={{display:"flex",flexDirection:"column",gap:16}}>
    <Card glow className="fu">
      <div style={{fontFamily:"'Syne',sans-serif",fontSize:17,fontWeight:700,marginBottom:4}}>{t.wps}</div>
      <div style={{fontSize:11,color:C.dim,marginBottom:14}}>UAE Wage Protection System — Native SIF File Generator · WPS 2.0 Compliant</div>
      <div style={{padding:"12px 16px",background:`${C.orange}10`,border:`1px solid ${C.orange}40`,borderRadius:10,marginBottom:16}}>
        <div style={{fontWeight:700,fontSize:12,color:C.orange,marginBottom:3}}>⚠ WPS 2.0 — Mandatory July 2026</div>
        <div style={{fontSize:11,color:C.dim,lineHeight:1.7}}>Real-time wage integration required by UAE Central Bank. Batch SIF file uploads mandatory. Non-compliance freezes MOHRE portal and blocks all new visa processing.</div>
      </div>
      <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"flex-end",marginBottom:16}}>
        <div>
          <label style={{fontSize:10,fontWeight:700,color:C.sub,letterSpacing:.7,textTransform:"uppercase",display:"block",marginBottom:5}}>{t.wpsPayroll}</label>
          <input type="month" value={month} onChange={e=>setMonth(e.target.value)} style={{background:C.bg,border:`1.5px solid ${C.border}`,color:C.text,borderRadius:9,padding:"9px 13px",fontSize:13,outline:"none",fontFamily:"inherit"}}/>
        </div>
        <Btn onClick={generate}>⚙️ {t.wpsGenerate}</Btn>
        {preview&&<Btn v="green" onClick={download}>⬇ {t.wpsDownload}</Btn>}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(140px,1fr))",gap:10,marginBottom:16}}>
        {[{l:"In WPS",v:withSalary.length,c:C.blue},{l:"Total Payroll",v:`AED ${total.toLocaleString()}`,c:C.green},{l:"Missing Salary",v:activeEmps.filter(e=>!e.salary).length,c:activeEmps.filter(e=>!e.salary).length>0?C.red:C.dim},{l:"Status",v:"Ready",c:C.green}].map((s,i)=><Card key={i} style={{textAlign:"center",padding:14}}>
          <div style={{fontFamily:"'Syne',sans-serif",fontSize:16,fontWeight:800,color:s.c}}>{s.v}</div>
          <div style={{fontSize:10,color:C.dim,marginTop:3}}>{s.l}</div>
        </Card>)}
      </div>
    </Card>
    {preview&&<Card className="fu" style={{animationDelay:".1s"}}>
      <div style={{fontFamily:"'Syne',sans-serif",fontSize:13,fontWeight:700,marginBottom:12,color:C.green}}>✓ {t.wpsPreview} — UAE Central Bank Format</div>
      <div style={{background:"#000",borderRadius:10,padding:16,fontFamily:"'Courier New',monospace",fontSize:11,color:"#00ff88",lineHeight:2,overflowX:"auto",border:`1px solid ${C.green}30`}}>
        {preview.split("\n").map((line,i)=><div key={i} style={{color:line.startsWith("H")?"#ffaa00":line.startsWith("T")?C.goldL:"#00ff88"}}>{line}</div>)}
      </div>
      <div style={{marginTop:10,fontSize:10,color:C.dim}}><strong style={{color:C.orange}}>H</strong> = Header · <strong style={{color:C.green}}>D</strong> = Employee salary · <strong style={{color:C.goldL}}>T</strong> = Totals</div>
    </Card>}
    <Card className="fu" style={{animationDelay:".18s"}}>
      <div style={{fontFamily:"'Syne',sans-serif",fontSize:13,fontWeight:700,marginBottom:12}}>{t.wpsEmpReg}</div>
      {activeEmps.map((emp,i)=><div key={emp.id} style={{display:"flex",gap:11,alignItems:"center",padding:"8px 12px",background:C.bg,borderRadius:10,marginBottom:7,border:`1px solid ${emp.salary>0?C.border:C.red+"30"}`}}>
        <div style={{width:32,height:32,borderRadius:9,background:`linear-gradient(135deg,${C.goldD},${C.gold}50)`,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:10,color:C.goldL,flexShrink:0}}>{emp.name.split(" ").map(w=>w[0]).join("").slice(0,2)}</div>
        <div style={{flex:1}}><div style={{fontWeight:600,fontSize:12}}>{emp.name}</div><div style={{fontSize:10,color:C.dim}}>{emp.role}</div></div>
        {emp.salary>0?<Bdg color={C.green}>AED {emp.salary.toLocaleString()}/mo</Bdg>:<Bdg color={C.red}>⚠ {t.noSalary}</Bdg>}
      </div>)}
    </Card>
  </div>;
}

// ═══════════════════════════════════════════════════════════
// VISA DETECTOR
// ═══════════════════════════════════════════════════════════
function VisaPage({t,emps,saveE,addToast}){
  const [editId,setEditId]=useState(null);
  const [newDate,setNewDate]=useState("");
  const active=emps.filter(e=>e.active);
  const groups=[
    {key:"expired",label:t.expired,color:C.red},
    {key:"critical",label:t.critical,color:C.orange},
    {key:"warning",label:t.warning,color:"#ffdd00"},
    {key:"ok",label:t.valid,color:C.green},
    {key:null,label:t.noData,color:C.dim},
  ].map(g=>({...g,list:active.filter(e=>visaStatus(e.visaExpiry)===g.key)})).filter(g=>g.list.length>0);

  const saveVisa=()=>{
    if(!editId||!newDate)return;
    saveE(emps.map(e=>e.id===editId?{...e,visaExpiry:newDate}:e));
    setEditId(null);setNewDate("");addToast("Visa expiry updated ✓");
  };

  return <div style={{display:"flex",flexDirection:"column",gap:16}}>
    <Card glow className="fu" style={{borderColor:active.filter(e=>visaStatus(e.visaExpiry)==="expired").length>0?C.red:C.border}}>
      <div style={{fontFamily:"'Syne',sans-serif",fontSize:17,fontWeight:700,marginBottom:4}}>🛂 {t.visaDetector}</div>
      <div style={{fontSize:11,color:C.dim,marginBottom:14}}>Track residency visa expiry for all employees. Expired visa = illegal work authorization.</div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(120px,1fr))",gap:10}}>
        {[
          {n:active.filter(e=>visaStatus(e.visaExpiry)==="expired").length,l:t.expired,c:C.red,icon:"🔴"},
          {n:active.filter(e=>visaStatus(e.visaExpiry)==="critical").length,l:t.critical,c:C.orange,icon:"🟠"},
          {n:active.filter(e=>visaStatus(e.visaExpiry)==="warning").length,l:t.warning,c:"#ffdd00",icon:"🟡"},
          {n:active.filter(e=>visaStatus(e.visaExpiry)==="ok").length,l:t.valid,c:C.green,icon:"🟢"},
          {n:active.filter(e=>!e.visaExpiry).length,l:t.noData,c:C.dim,icon:"⚪"},
        ].map((s,i)=><Card key={i} style={{textAlign:"center",padding:14}}>
          <div style={{fontSize:18,marginBottom:4}}>{s.icon}</div>
          <div style={{fontFamily:"'Syne',sans-serif",fontSize:22,fontWeight:800,color:s.c}}>{s.n}</div>
          <div style={{fontSize:10,color:C.dim,marginTop:2}}>{s.l}</div>
        </Card>)}
      </div>
    </Card>
    {groups.map((g,gi)=><Card key={gi} className="fu" style={{animationDelay:`${gi*.08}s`,borderColor:`${g.color}35`}}>
      <div style={{fontWeight:700,fontSize:13,color:g.color,marginBottom:4}}>{g.key==="expired"?"🔴":g.key==="critical"?"🟠":g.key==="warning"?"🟡":g.key==="ok"?"🟢":"⚪"} {g.label}</div>
      {g.list.map((emp,i)=>{
        const vd=visaDays(emp.visaExpiry);
        return <div key={emp.id} style={{display:"flex",gap:12,padding:"10px 14px",background:C.bg,borderRadius:11,marginBottom:8,border:`1px solid ${g.color}22`,alignItems:"center",flexWrap:"wrap",gap:10}}>
          <div style={{width:34,height:34,borderRadius:9,background:`linear-gradient(135deg,${C.goldD},${C.gold}50)`,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:11,color:C.goldL,flexShrink:0}}>{emp.name.split(" ").map(w=>w[0]).join("").slice(0,2)}</div>
          <div style={{flex:1}}>
            <div style={{fontWeight:700,fontSize:13}}>{emp.name}</div>
            <div style={{fontSize:11,color:C.dim}}>{emp.role} · {emp.nationality}</div>
            {emp.visaExpiry&&<div style={{fontSize:11,color:g.color,marginTop:2,fontWeight:600}}>{vd<0?`Expired ${Math.abs(vd)} days ago`:vd===0?"Expires today":`${emp.visaExpiry} (${vd} days)`}</div>}
          </div>
          <div style={{display:"flex",gap:7,alignItems:"center"}}>
            <Bdg color={isEmirati(emp.nationality)?C.green:C.sub}>{emp.nationality==="Emirati"?"🇦🇪":emp.nationality}</Bdg>
            {editId===emp.id?<div style={{display:"flex",gap:6,alignItems:"center"}}>
              <input type="date" value={newDate} onChange={e=>setNewDate(e.target.value)} style={{background:C.bg,border:`1.5px solid ${C.goldD}`,color:C.text,borderRadius:8,padding:"6px 10px",fontSize:11,outline:"none",fontFamily:"inherit"}}/>
              <Btn v="green" sz="sm" onClick={saveVisa}>Save</Btn>
              <Btn v="ghost" sz="sm" onClick={()=>setEditId(null)}>✕</Btn>
            </div>:<Btn v="outline" sz="sm" onClick={()=>{setEditId(emp.id);setNewDate(emp.visaExpiry||"");}}>{t.updateVisa}</Btn>}
          </div>
        </div>;
      })}
    </Card>)}
  </div>;
}

// ═══════════════════════════════════════════════════════════
// PROBATION TRACKER
// ═══════════════════════════════════════════════════════════
function ProbationPage({t,emps,saveE,addToast,lang}){
  const active=emps.filter(e=>e.active);
  const onProbation=active.filter(e=>probationStatus(e.joinDate)==="active");
  const completed=active.filter(e=>probationStatus(e.joinDate)==="completed");
  const noDate=active.filter(e=>!e.joinDate);
  const [editId,setEditId]=useState(null);
  const [newDate,setNewDate]=useState("");

  const saveJoin=()=>{
    if(!editId||!newDate)return;
    saveE(emps.map(e=>e.id===editId?{...e,joinDate:newDate}:e));
    setEditId(null);setNewDate("");
    addToast("Join date updated ✓");
  };

  const ProbBar=({pct,color})=>(
    <div style={{background:C.bg,borderRadius:6,height:8,overflow:"hidden",marginTop:6}}>
      <div style={{height:"100%",borderRadius:6,background:`linear-gradient(90deg,${color},${color}aa)`,width:`${pct}%`,transition:"width 1s"}}/>
    </div>
  );

  return <div style={{display:"flex",flexDirection:"column",gap:16}}>
    {/* Header */}
    <Card glow className="fu" style={{borderColor:C.purple}}>
      <div style={{fontFamily:"'Syne',sans-serif",fontSize:17,fontWeight:700,marginBottom:4}}>🆕 {t.probationTitle||"Probation Tracker"}</div>
      <div style={{fontSize:11,color:C.dim,marginBottom:16}}>UAE Federal Decree Law No. 33 of 2021 — Article 9 · Maximum 6-month probation period</div>
      {/* Stats */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(140px,1fr))",gap:12}}>
        {[
          {n:onProbation.length,l:"On Probation",c:C.purple,icon:"🆕"},
          {n:completed.length,l:"Completed",c:C.green,icon:"✅"},
          {n:noDate.length,l:"No Join Date",c:C.dim,icon:"❓"},
          {n:active.length,l:"Total Active",c:C.blue,icon:"👥"},
        ].map((s,i)=><Card key={i} style={{textAlign:"center",padding:14}}>
          <div style={{fontSize:22,marginBottom:5}}>{s.icon}</div>
          <div style={{fontFamily:"'Syne',sans-serif",fontSize:22,fontWeight:800,color:s.c}}>{s.n}</div>
          <div style={{fontSize:10,color:C.dim,marginTop:2}}>{s.l}</div>
        </Card>)}
      </div>
    </Card>

    {/* UAE Law Box */}
    <Card className="fu" style={{animationDelay:".1s",background:`linear-gradient(135deg,${C.card},#0e0a1e)`,border:`1.5px solid ${C.purple}40`}}>
      <div style={{fontFamily:"'Syne',sans-serif",fontSize:14,fontWeight:700,color:C.purple,marginBottom:12}}>📋 UAE Probation Law — What JADWAL Enforces</div>
      {[
        {icon:"⏱️",rule:"Maximum 6 months",detail:"UAE law caps probation at 6 months from join date. Cannot be extended or repeated for the same employee."},
        {icon:"📢",rule:"14-day termination notice",detail:"Employer can terminate during probation with 14 days written notice. Employee can also resign with 14 days notice."},
        {icon:"💰",rule:"No end-of-service gratuity",detail:"If an employee resigns during probation, they are not entitled to end-of-service gratuity payment."},
        {icon:"🔄",rule:"No re-probation",detail:"Once probation is completed, the same employee cannot be put on probation again at the same company."},
        {icon:"🏛️",rule:"MOHRE notification",detail:"Changes made during probation (termination, role change) should be reflected in the MOHRE portal within 14 days."},
        {icon:"🛡️",rule:"Emirati protection",detail:"UAE nationals cannot be terminated during probation without prior MOHRE approval. Extra protection applies."},
      ].map((r,i)=><div key={i} style={{display:"flex",gap:10,padding:"9px 0",borderBottom:i<5?`1px solid ${C.border}10`:undefined}}>
        <div style={{width:34,height:34,borderRadius:9,background:`${C.purple}18`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,flexShrink:0}}>{r.icon}</div>
        <div><div style={{fontWeight:700,fontSize:12,color:C.purple}}>{r.rule}</div><div style={{fontSize:11,color:C.dim,marginTop:2,lineHeight:1.6}}>{r.detail}</div></div>
      </div>)}
    </Card>

    {/* Active Probation */}
    {onProbation.length>0&&<Card className="fu" style={{animationDelay:".2s",borderColor:C.purple+"40"}}>
      <div style={{fontFamily:"'Syne',sans-serif",fontSize:14,fontWeight:700,color:C.purple,marginBottom:14}}>🆕 Currently on Probation — {onProbation.length} Employee{onProbation.length>1?"s":""}</div>
      {onProbation.map((emp,i)=>{
        const pct=probationPct(emp.joinDate);
        const dLeft=probationDaysLeft(emp.joinDate);
        const endDate=formatProbationEnd(emp.joinDate);
        const dElapsed=probationDaysElapsed(emp.joinDate);
        return <div key={emp.id} style={{background:C.bg,borderRadius:14,padding:16,marginBottom:10,border:`1px solid ${C.purple}30`}}>
          <div style={{display:"flex",gap:12,alignItems:"flex-start",flexWrap:"wrap",marginBottom:12}}>
            <div style={{width:42,height:42,borderRadius:11,background:`linear-gradient(135deg,${C.goldD},${C.gold}55)`,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:13,color:C.goldL,flexShrink:0}}>{emp.name.split(" ").map(w=>w[0]).join("").slice(0,2)}</div>
            <div style={{flex:1}}>
              <div style={{fontWeight:700,fontSize:14}}>{emp.name}</div>
              <div style={{fontSize:11,color:C.gold,marginBottom:2}}>{emp.role}</div>
              <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
                <span style={{fontSize:10,color:C.dim}}>📅 Joined: {emp.joinDate}</span>
                <span style={{fontSize:10,color:C.purple}}>🏁 Ends: {endDate}</span>
                <span style={{fontSize:10,color:isEmirati(emp.nationality)?C.green:C.dim}}>{emp.nationality==="Emirati"?"🇦🇪 Emirati":emp.nationality}</span>
              </div>
            </div>
            <Bdg color={C.purple}>{dLeft} days left</Bdg>
          </div>
          {/* Progress bar */}
          <div style={{display:"flex",justifyContent:"space-between",fontSize:10,color:C.dim,marginBottom:4}}>
            <span>Day {dElapsed} of 180</span>
            <span>{pct}% complete</span>
            <span>{dLeft} days remaining</span>
          </div>
          <ProbBar pct={pct} color={pct<50?C.orange:pct<80?C.gold:C.green}/>
          {/* Warning if near end */}
          {dLeft<=30&&dLeft>0&&<div style={{marginTop:10,padding:"7px 10px",background:`${C.gold}10`,border:`1px solid ${C.goldD}`,borderRadius:8,fontSize:11,color:C.gold}}>⚠ Probation ends in {dLeft} days. Decide now: confirm employment or issue 14-day termination notice.</div>}
          {isEmirati(emp.nationality)&&<div style={{marginTop:8,padding:"7px 10px",background:`${C.green}10`,border:`1px solid ${C.green}40`,borderRadius:8,fontSize:11,color:C.green}}>🇦🇪 UAE National on probation — termination requires prior MOHRE approval.</div>}
        </div>;
      })}
    </Card>}

    {/* Completed Probation */}
    {completed.length>0&&<Card className="fu" style={{animationDelay:".28s",borderColor:C.green+"30"}}>
      <div style={{fontFamily:"'Syne',sans-serif",fontSize:14,fontWeight:700,color:C.green,marginBottom:14}}>✅ Probation Completed — {completed.length} Employee{completed.length>1?"s":""}</div>
      {completed.map((emp,i)=><div key={emp.id} style={{display:"flex",gap:12,padding:"10px 12px",background:C.bg,borderRadius:11,marginBottom:7,border:`1px solid ${C.green}22`,alignItems:"center",flexWrap:"wrap",gap:10}}>
        <div style={{width:34,height:34,borderRadius:9,background:`linear-gradient(135deg,${C.goldD},${C.gold}50)`,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:11,color:C.goldL,flexShrink:0}}>{emp.name.split(" ").map(w=>w[0]).join("").slice(0,2)}</div>
        <div style={{flex:1}}>
          <div style={{fontWeight:700,fontSize:12}}>{emp.name}</div>
          <div style={{fontSize:10,color:C.dim}}>{emp.role} · Joined: {emp.joinDate} · Probation ended: {formatProbationEnd(emp.joinDate)}</div>
        </div>
        <Bdg color={C.green}>✓ Full Employee</Bdg>
        <Bdg color={isEmirati(emp.nationality)?C.green:C.sub}>{emp.nationality==="Emirati"?"🇦🇪":emp.nationality}</Bdg>
      </div>)}
    </Card>}

    {/* No join date */}
    {noDate.length>0&&<Card className="fu" style={{animationDelay:".36s",borderColor:C.dim+"30"}}>
      <div style={{fontFamily:"'Syne',sans-serif",fontSize:14,fontWeight:700,color:C.sub,marginBottom:12}}>❓ No Join Date — Add to Track Probation</div>
      {noDate.map((emp,i)=><div key={emp.id} style={{display:"flex",gap:12,padding:"10px 14px",background:C.bg,borderRadius:11,marginBottom:7,border:`1px solid ${C.border}`,alignItems:"center",flexWrap:"wrap",gap:10}}>
        <div style={{width:34,height:34,borderRadius:9,background:`linear-gradient(135deg,${C.goldD},${C.gold}50)`,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:11,color:C.goldL,flexShrink:0}}>{emp.name.split(" ").map(w=>w[0]).join("").slice(0,2)}</div>
        <div style={{flex:1}}>
          <div style={{fontWeight:700,fontSize:12}}>{emp.name}</div>
          <div style={{fontSize:10,color:C.dim}}>{emp.role} · {emp.nationality}</div>
        </div>
        {editId===emp.id?<div style={{display:"flex",gap:6,alignItems:"center"}}>
          <input type="date" value={newDate} onChange={e=>setNewDate(e.target.value)} style={{background:C.bg,border:`1.5px solid ${C.goldD}`,color:C.text,borderRadius:8,padding:"6px 10px",fontSize:11,outline:"none",fontFamily:"inherit"}}/>
          <Btn v="green" sz="sm" onClick={saveJoin}>Save</Btn>
          <Btn v="ghost" sz="sm" onClick={()=>setEditId(null)}>✕</Btn>
        </div>:<Btn v="outline" sz="sm" onClick={()=>{setEditId(emp.id);setNewDate(new Date().toISOString().slice(0,10));}}>Add Join Date</Btn>}
      </div>)}
    </Card>}
  </div>;
}

// ═══════════════════════════════════════════════════════════
// HR + VISA AUTOMATION — MOHRE ECOSYSTEM
// ═══════════════════════════════════════════════════════════
function HRPage({t,emps,saveE,addToast,lang}){
  const [tab,setTab]=useState("permits");
  const [eosEmp,setEosEmp]=useState(null);
  const [leaveModal,setLeaveModal]=useState(null);
  const [leaveForm,setLeaveForm]=useState({type:"annual",days:1,reason:""});
  const [docModal,setDocModal]=useState(null);
  const active=emps.filter(e=>e.active);
  const permitDays=d=>d?Math.round((new Date(d)-new Date())/86400000):null;
  const permitStatus=d=>{const v=permitDays(d);if(v===null)return null;if(v<0)return"expired";if(v<=30)return"critical";if(v<=60)return"warning";return"ok";};

  const calcEOS=(emp)=>{
    if(!emp.joinDate||!emp.salary)return 0;
    const years=(new Date()-new Date(emp.joinDate))/(365.25*86400000);
    const basic=emp.salary*0.6; // assume 60% basic
    if(years<1)return 0;
    if(years<=5)return Math.round(basic/30*21*years);
    return Math.round(basic/30*21*5 + basic/30*30*(years-5));
  };

  const updateLeave=(emp,type,days)=>{
    const field=type==="annual"?"annualUsed":"sickUsed";
    const current=emp[field]||0;
    saveE(emps.map(e=>e.id===emp.id?{...e,[field]:current+days}:e));
    addToast(`${days} day${days>1?"s":""} ${type} leave recorded ✓`);
    setLeaveModal(null);
  };

  const toggleDoc=(emp,doc)=>{
    const docs={...emp.docs,[doc]:!emp.docs?.[doc]};
    saveE(emps.map(e=>e.id===emp.id?{...e,docs}:e));
    addToast("Document status updated ✓");
  };

  const permitAlerts=active.filter(e=>["expired","critical","warning"].includes(permitStatus(e.permitExpiry)));
  const missingDocs=active.filter(e=>{const d=e.docs||{};return !d.passport||!d.eid||!d.visa||!d.contract;});
  const leaveAlerts=active.filter(e=>(e.annualUsed||0)>=(e.annualLeave||30));

  const TABS=[
    {id:"permits",icon:"📋",label:"Work Permits"},
    {id:"leave",icon:"🏖️",label:"Leave Management"},
    {id:"docs",icon:"📁",label:"Documents"},
    {id:"eos",icon:"💰",label:"EOS Calculator"},
    {id:"actions",icon:"🏛️",label:"MOHRE Actions"},
    {id:"onboarding",icon:"✅",label:"Onboarding"},
  ];

  const tabBtn=(tb)=>(
    <button key={tb.id} onClick={()=>setTab(tb.id)} style={{
      padding:"8px 14px",borderRadius:9,border:`1.5px solid ${tab===tb.id?C.gold:C.border}`,
      background:tab===tb.id?`${C.gold}14`:C.card,color:tab===tb.id?C.gold:C.sub,
      fontWeight:tab===tb.id?700:500,fontSize:11,cursor:"pointer",
      fontFamily:"inherit",display:"flex",alignItems:"center",gap:6,whiteSpace:"nowrap",
      transition:"all .15s"
    }}><span>{tb.icon}</span>{tb.label}</button>
  );

  return <div style={{display:"flex",flexDirection:"column",gap:16}}>
    {/* Header */}
    <Card glow className="fu" style={{borderColor:C.blue}}>
      <div style={{fontFamily:"'Syne',sans-serif",fontSize:17,fontWeight:700,marginBottom:4}}>
        📋 {t.hrTitle||"HR & Visa Automation"}
      </div>
      <div style={{fontSize:11,color:C.dim,marginBottom:14}}>{t.hrDesc||"MOHRE Ecosystem — Work Permits · Visas · Documents · Leave · EOS"}</div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(130px,1fr))",gap:10}}>
        {[
          {n:permitAlerts.length,l:"Permit Alerts",c:permitAlerts.length>0?C.red:C.green,icon:"📋"},
          {n:missingDocs.length,l:"Missing Docs",c:missingDocs.length>0?C.orange:C.green,icon:"📁"},
          {n:leaveAlerts.length,l:"Leave Exhausted",c:leaveAlerts.length>0?C.orange:C.green,icon:"🏖️"},
          {n:active.length,l:"Active Staff",c:C.blue,icon:"👥"},
        ].map((s,i)=><div key={i} style={{background:C.bg,borderRadius:11,padding:"12px",textAlign:"center",border:`1px solid ${s.c}22`}}>
          <div style={{fontSize:20,marginBottom:5}}>{s.icon}</div>
          <div style={{fontFamily:"'Syne',sans-serif",fontSize:20,fontWeight:800,color:s.c}}>{s.n}</div>
          <div style={{fontSize:10,color:C.dim,marginTop:2}}>{s.l}</div>
        </div>)}
      </div>
    </Card>

    {/* Tab bar */}
    <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
      {TABS.map(tb=>tabBtn(tb))}
    </div>

    {/* ── WORK PERMITS ── */}
    {tab==="permits"&&<div style={{display:"flex",flexDirection:"column",gap:10}} className="fu">
      <Card style={{background:`${C.blueD}`,border:`1.5px solid ${C.blue}40`,padding:"12px 16px"}}>
        <div style={{fontSize:12,color:C.blue,fontWeight:700,marginBottom:3}}>🏛️ UAE Work Permit System</div>
        <div style={{fontSize:11,color:C.sub,lineHeight:1.7}}>Work permits are issued by MOHRE and linked to each employee's residency visa. They must be renewed before expiry. Expired work permits = illegal employment. JADWAL tracks every permit and alerts you 60 days before expiry.</div>
      </Card>
      {active.map((emp,i)=>{
        const ps=permitStatus(emp.permitExpiry);
        const pd=permitDays(emp.permitExpiry);
        const pColor=ps==="expired"?C.red:ps==="critical"?C.red:ps==="warning"?C.orange:ps==="ok"?C.green:C.dim;
        return <Card key={emp.id} className="fu" style={{animationDelay:`${i*.04}s`,border:`1.5px solid ${pColor}30`}}>
          <div style={{display:"flex",gap:12,alignItems:"center",flexWrap:"wrap"}}>
            <div style={{width:40,height:40,borderRadius:11,background:`linear-gradient(135deg,${C.goldD},${C.gold}55)`,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:12,color:C.goldL,flexShrink:0}}>{emp.name.split(" ").map(w=>w[0]).join("").slice(0,2)}</div>
            <div style={{flex:1,minWidth:160}}>
              <div style={{fontWeight:700,fontSize:13}}>{emp.name}</div>
              <div style={{fontSize:11,color:C.gold}}>{emp.role}</div>
              <div style={{fontSize:10,color:C.dim,marginTop:2}}>
                Permit: <span style={{color:C.text,fontWeight:600}}>{emp.permitNo||"Not set"}</span>
                {emp.permitExpiry&&<span style={{marginLeft:12,color:pColor,fontWeight:600}}>
                  {ps==="expired"?"🔴 EXPIRED":ps==="critical"?`🔴 ${pd} days left`:ps==="warning"?`🟠 ${pd} days left`:`🟢 ${pd} days`}
                </span>}
              </div>
            </div>
            <div style={{display:"flex",gap:7,alignItems:"center",flexWrap:"wrap"}}>
              <Bdg color={isEmirati(emp.nationality)?C.green:C.sub}>{emp.nationality==="Emirati"?"🇦🇪":emp.nationality}</Bdg>
              {ps&&<Bdg color={pColor}>{ps==="ok"?"✓ Valid":ps==="warning"?"Renew Soon":ps==="critical"?"Urgent!":"EXPIRED"}</Bdg>}
            </div>
            {ps&&ps!=="ok"&&<Btn v="blue" sz="sm" onClick={()=>addToast(`Renewal request prepared for ${emp.name} — submit via MOHRE portal ✓`)}>
              Apply Renewal
            </Btn>}
          </div>
          {(ps==="expired"||ps==="critical")&&<div style={{marginTop:10,padding:"8px 12px",background:C.redD,border:`1px solid ${C.red}40`,borderRadius:8,fontSize:11,color:C.red}}>
            ⚠ Action required — expired work permit is a MOHRE violation. Submit renewal via <strong>eservices.mohre.gov.ae</strong> immediately.
          </div>}
          {emp.nationality==="Emirati"&&<div style={{marginTop:8,padding:"7px 12px",background:C.greenD,border:`1px solid ${C.green}40`,borderRadius:8,fontSize:11,color:C.green}}>
            🇦🇪 UAE National — labour card renewal via NAFIS portal at <strong>nafis.gov.ae</strong>
          </div>}
        </Card>;
      })}
    </div>}

    {/* ── LEAVE MANAGEMENT ── */}
    {tab==="leave"&&<div style={{display:"flex",flexDirection:"column",gap:10}} className="fu">
      <Card style={{background:`${C.greenD}`,border:`1.5px solid ${C.green}40`,padding:"12px 16px"}}>
        <div style={{fontSize:12,color:C.green,fontWeight:700,marginBottom:3}}>📋 UAE Leave Entitlements — Federal Decree Law 33/2021</div>
        <div style={{display:"flex",gap:16,flexWrap:"wrap",marginTop:6}}>
          {[["Annual Leave","30 days/year after 1 year","After 6 months: 2 days/month",GREEN],
            ["Sick Leave","60 days/year","First 15 = full pay · Next 30 = half · Last 15 = unpaid",C.orange],
            ["Maternity Leave","60 days","45 days full pay + 15 days half pay",C.purple],
            ["Hajj Leave","30 days (once)","Unpaid · Muslims only · Once per employment",C.gold],
          ].map(([l,v,d,c],i)=><div key={i} style={{background:C.bg,borderRadius:10,padding:"10px 14px",flex:"1 1 160px"}}>
            <div style={{fontWeight:700,fontSize:12,color:c}}>{l}</div>
            <div style={{fontSize:11,color:C.text,marginTop:2}}>{v}</div>
            <div style={{fontSize:9,color:C.dim,marginTop:2}}>{d}</div>
          </div>)}
        </div>
      </Card>
      {active.map((emp,i)=>{
        const aTotal=emp.annualLeave||30; const aUsed=emp.annualUsed||0; const aLeft=aTotal-aUsed;
        const sTotal=emp.sickLeave||60; const sUsed=emp.sickUsed||0; const sLeft=sTotal-sUsed;
        const aPct=Math.min(100,Math.round(aUsed/aTotal*100));
        return <Card key={emp.id} className="fu" style={{animationDelay:`${i*.04}s`}}>
          <div style={{display:"flex",gap:12,alignItems:"flex-start",flexWrap:"wrap"}}>
            <div style={{width:38,height:38,borderRadius:10,background:`linear-gradient(135deg,${C.goldD},${C.gold}55)`,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:11,color:C.goldL,flexShrink:0}}>{emp.name.split(" ").map(w=>w[0]).join("").slice(0,2)}</div>
            <div style={{flex:1,minWidth:200}}>
              <div style={{fontWeight:700,fontSize:13,marginBottom:8}}>{emp.name} <span style={{fontSize:10,color:C.gold,fontWeight:400}}>· {emp.role}</span></div>
              {/* Annual */}
              <div style={{display:"flex",justifyContent:"space-between",fontSize:11,marginBottom:4}}>
                <span style={{color:C.sub}}>Annual Leave</span>
                <span style={{color:aLeft<=5?C.red:C.green,fontWeight:700}}>{aLeft} days remaining / {aTotal}</span>
              </div>
              <div style={{background:C.bg,borderRadius:5,height:7,overflow:"hidden",marginBottom:8}}>
                <div style={{height:"100%",borderRadius:5,background:`linear-gradient(90deg,${aLeft<=5?C.red:C.green},${C.goldL})`,width:`${aPct}%`,transition:"width 1s"}}/>
              </div>
              {/* Sick */}
              <div style={{display:"flex",justifyContent:"space-between",fontSize:11,marginBottom:4}}>
                <span style={{color:C.sub}}>Sick Leave</span>
                <span style={{color:sLeft<=10?C.orange:C.blue,fontWeight:700}}>{sLeft} days remaining / {sTotal}</span>
              </div>
              <div style={{background:C.bg,borderRadius:5,height:7,overflow:"hidden"}}>
                <div style={{height:"100%",borderRadius:5,background:C.blue,width:`${Math.min(100,Math.round(sUsed/sTotal*100))}%`,transition:"width 1s"}}/>
              </div>
            </div>
            <Btn v="green" sz="sm" onClick={()=>{setLeaveModal(emp);setLeaveForm({type:"annual",days:1,reason:""});}}>+ Record Leave</Btn>
          </div>
        </Card>;
      })}
    </div>}

    {/* ── DOCUMENTS ── */}
    {tab==="docs"&&<div style={{display:"flex",flexDirection:"column",gap:10}} className="fu">
      <Card style={{background:`${C.orangeD}`,border:`1.5px solid ${C.orange}40`,padding:"12px 16px"}}>
        <div style={{fontSize:12,color:C.orange,fontWeight:700,marginBottom:3}}>📁 Required Documents — MOHRE Compliance</div>
        <div style={{fontSize:11,color:C.sub,lineHeight:1.7}}>Every employee must have all 5 documents on file before their first shift. MOHRE inspectors can request these at any time. Missing documents = immediate violation. JADWAL tracks document status for every employee.</div>
      </Card>
      {active.map((emp,i)=>{
        const docs=emp.docs||{}; const total=5;
        const complete=Object.values(docs).filter(Boolean).length;
        const pct=Math.round(complete/total*100);
        const DOCLIST=[
          {key:"passport",label:"Passport Copy",icon:"📕"},
          {key:"eid",label:"Emirates ID Copy",icon:"🪪"},
          {key:"visa",label:"Visa / Residence Copy",icon:"📄"},
          {key:"contract",label:"Employment Contract",icon:"📝"},
          {key:"medical",label:"Medical Certificate",icon:"🏥"},
        ];
        return <Card key={emp.id} className="fu" style={{animationDelay:`${i*.04}s`,border:`1.5px solid ${pct===100?C.green+"30":pct<60?C.red+"30":C.orange+"30"}`}}>
          <div style={{display:"flex",gap:12,alignItems:"flex-start",marginBottom:12}}>
            <div style={{width:38,height:38,borderRadius:10,background:`linear-gradient(135deg,${C.goldD},${C.gold}55)`,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:11,color:C.goldL,flexShrink:0}}>{emp.name.split(" ").map(w=>w[0]).join("").slice(0,2)}</div>
            <div style={{flex:1}}>
              <div style={{fontWeight:700,fontSize:13}}>{emp.name}</div>
              <div style={{fontSize:10,color:C.gold}}>{emp.role}</div>
            </div>
            <Bdg color={pct===100?C.green:pct<60?C.red:C.orange}>{complete}/{total} complete</Bdg>
          </div>
          <div style={{background:C.bg,borderRadius:5,height:6,overflow:"hidden",marginBottom:10}}>
            <div style={{height:"100%",borderRadius:5,background:pct===100?C.green:pct<60?C.red:C.orange,width:`${pct}%`,transition:"width 1s"}}/>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(140px,1fr))",gap:7}}>
            {DOCLIST.map(d=>(
              <button key={d.key} onClick={()=>toggleDoc(emp,d.key)} style={{
                display:"flex",gap:8,alignItems:"center",padding:"8px 10px",
                background:docs[d.key]?C.greenD:C.redD,
                border:`1px solid ${docs[d.key]?C.green+"40":C.red+"40"}`,
                borderRadius:9,cursor:"pointer",fontFamily:"inherit",
                color:docs[d.key]?C.green:C.red,fontSize:11,fontWeight:600,textAlign:"left"
              }}>
                <span style={{fontSize:14}}>{d.icon}</span>
                <span style={{flex:1,fontSize:10}}>{d.label}</span>
                <span>{docs[d.key]?"✓":"✗"}</span>
              </button>
            ))}
          </div>
        </Card>;
      })}
    </div>}

    {/* ── EOS CALCULATOR ── */}
    {tab==="eos"&&<div style={{display:"flex",flexDirection:"column",gap:10}} className="fu">
      <Card style={{background:`${C.goldGlow||C.goldD+"20"}`,border:`1.5px solid ${C.goldD}`,padding:"12px 16px"}}>
        <div style={{fontSize:12,color:C.gold,fontWeight:700,marginBottom:3}}>💰 End of Service Gratuity — UAE Federal Law</div>
        <div style={{fontSize:11,color:C.sub,lineHeight:1.7}}>Based on Federal Decree Law No. 33 of 2021. Formula: 21 days basic salary per year for first 5 years · 30 days per year beyond 5 years. Calculated on basic salary (typically 60% of total salary). Payable upon termination or resignation after 1+ year.</div>
      </Card>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))",gap:12}}>
        {active.filter(e=>e.joinDate&&e.salary>0).map((emp,i)=>{
          const years=(new Date()-new Date(emp.joinDate))/(365.25*86400000);
          const basic=emp.salary*0.6;
          const eos=calcEOS(emp);
          const months=Math.floor((years%1)*12);
          return <Card key={emp.id} className="fu" style={{animationDelay:`${i*.06}s`,border:`1.5px solid ${C.goldD}30`}}>
            <div style={{display:"flex",gap:10,alignItems:"center",marginBottom:12}}>
              <div style={{width:36,height:36,borderRadius:9,background:`linear-gradient(135deg,${C.goldD},${C.gold}55)`,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:11,color:C.goldL,flexShrink:0}}>{emp.name.split(" ").map(w=>w[0]).join("").slice(0,2)}</div>
              <div><div style={{fontWeight:700,fontSize:13}}>{emp.name}</div><div style={{fontSize:10,color:C.gold}}>{emp.role}</div></div>
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:6}}>
              {[["Service Period",`${Math.floor(years)}y ${months}m`,C.text],
                ["Total Salary",`AED ${emp.salary.toLocaleString()}/mo`,C.text],
                ["Basic Salary (60%)",`AED ${Math.round(basic).toLocaleString()}/mo`,C.text],
                ["EOS Gratuity",years>=1?`AED ${eos.toLocaleString()}`:"< 1 year — not eligible",years>=1?C.gold:C.dim],
              ].map(([l,v,c],j)=><div key={j} style={{display:"flex",justifyContent:"space-between",padding:"6px 10px",background:C.bg,borderRadius:7,border:`1px solid ${C.border}10`}}>
                <span style={{fontSize:11,color:C.dim}}>{l}</span>
                <span style={{fontSize:11,fontWeight:700,color:c}}>{v}</span>
              </div>)}
            </div>
          </Card>;
        })}
      </div>
      {active.filter(e=>!e.joinDate||!e.salary).length>0&&<Card style={{border:`1px solid ${C.orange}30`,padding:"12px 16px"}}>
        <div style={{fontSize:11,color:C.orange}}>⚠ {active.filter(e=>!e.joinDate||!e.salary).length} employees missing join date or salary data — cannot calculate EOS. Update in Employees tab.</div>
      </Card>}
    </div>}

    {/* ── MOHRE ACTIONS ── */}
    {tab==="actions"&&<div style={{display:"flex",flexDirection:"column",gap:12}} className="fu">
      <Card style={{background:C.blueD,border:`1.5px solid ${C.blue}40`,padding:"14px 18px"}}>
        <div style={{fontSize:13,color:C.blue,fontWeight:700,marginBottom:6}}>🏛️ MOHRE Quick Actions — UAE Ministry of HR & Emiratisation</div>
        <div style={{fontSize:11,color:C.sub}}>These links open directly in the UAE government portals. JADWAL prepares your data so every submission takes minutes, not hours.</div>
      </Card>
      {[
        {icon:"🏛️",title:"MOHRE eServices Portal",desc:"Apply/renew work permits, labor cards, and entry visas for all staff",action:"Open MOHRE Portal",url:"https://eservices.mohre.gov.ae",color:C.blue,badge:"Official Portal"},
        {icon:"🇦🇪",title:"NAFIS Portal — Emiratisation",desc:"Register Emirati employees, track NAFIS targets, check company classification",action:"Open NAFIS",url:"https://nafis.gov.ae",color:C.green,badge:"Emiratisation"},
        {icon:"💰",title:"WPS — Wage Protection System",desc:"Submit monthly SIF file for salary compliance. Download your SIF from the WPS tab first.",action:"Open WPS Portal",url:"https://www.centralbank.ae/en/bps/wps",color:C.gold,badge:"Mandatory July 2026"},
        {icon:"📋",title:"Labor Contract Registration",desc:"Register employment contracts within 14 days of joining — mandatory under Decree Law 33/2021",action:"Register Contracts",url:"https://eservices.mohre.gov.ae",color:C.purple,badge:"Within 14 days"},
        {icon:"🛂",title:"ICP — Immigration & Residency",desc:"Visa applications, renewals, change of status, and cancellations via Federal Authority for Identity",action:"Open ICP Portal",url:"https://icp.gov.ae",color:C.orange,badge:"Visa & Residency"},
        {icon:"🏥",title:"Medical Fitness Certificates",desc:"Book mandatory medical examinations for new employees and renewals via Dubai Health Authority",action:"Book Medical",url:"https://www.dha.gov.ae",color:C.red,badge:"Required for Visa"},
        {icon:"📊",title:"MOHRE Inspection Prep",desc:"JADWAL generates a full compliance checklist — work permits, WPS records, contracts, Emiratisation — ready for MOHRE inspection",action:"Generate Checklist",url:null,color:C.blue,badge:"Auto-Generated"},
      ].map((a,i)=><div key={i} className="fu" style={{animationDelay:`${i*.06}s`,background:C.card,border:`1.5px solid ${a.color}25`,borderRadius:16,padding:"16px 18px",display:"flex",gap:14,alignItems:"flex-start"}}>
        <div style={{width:44,height:44,borderRadius:12,background:`${a.color}18`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,flexShrink:0}}>{a.icon}</div>
        <div style={{flex:1}}>
          <div style={{display:"flex",gap:8,alignItems:"center",marginBottom:4,flexWrap:"wrap"}}>
            <div style={{fontWeight:700,fontSize:13,color:a.color}}>{a.title}</div>
            <Bdg color={a.color}>{a.badge}</Bdg>
          </div>
          <div style={{fontSize:11,color:C.sub,lineHeight:1.6,marginBottom:8}}>{a.desc}</div>
          <Btn v="outline" sz="sm" onClick={()=>{
            if(a.url){window.open(a.url,"_blank");addToast(`Opening ${a.title} →`);}
            else{addToast("Compliance checklist generated ✓ — all documents ready for inspection");}
          }} style={{borderColor:a.color,color:a.color}}>
            {a.action} →
          </Btn>
        </div>
      </div>)}
    </div>}

    {/* ── ONBOARDING ── */}
    {tab==="onboarding"&&<div style={{display:"flex",flexDirection:"column",gap:12}} className="fu">
      <Card style={{background:C.greenD,border:`1.5px solid ${C.green}40`,padding:"12px 16px"}}>
        <div style={{fontSize:12,color:C.green,fontWeight:700,marginBottom:3}}>✅ Onboarding & Offboarding Checklists</div>
        <div style={{fontSize:11,color:C.sub,lineHeight:1.7}}>UAE labor law requires specific steps within set timeframes. JADWAL tracks completion status for each new hire and departure.</div>
      </Card>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
        <Card className="fu">
          <div style={{fontFamily:"'Syne',sans-serif",fontSize:14,fontWeight:700,color:C.green,marginBottom:14}}>🆕 New Employee Onboarding</div>
          {[
            {step:"Day 1",task:"Collect passport + EID copy",law:"MOHRE requirement",done:true},
            {step:"Day 1",task:"Sign employment contract",law:"Decree Law 33 — Article 14",done:true},
            {step:"Day 1",task:"Add to JADWAL system",law:"Internal process",done:true},
            {step:"Day 7",task:"Apply for entry permit / labour card",law:"MOHRE eServices",done:false},
            {step:"Day 14",task:"Register contract on MOHRE portal",law:"Mandatory within 14 days",done:false},
            {step:"Day 14",task:"Complete medical fitness test",law:"DHA / MOH requirement",done:false},
            {step:"Day 30",task:"Activate WPS salary registration",law:"WPS compliance",done:false},
            {step:"Day 30",task:"Set up NAFIS Emirati record",law:"If UAE national",done:false},
            {step:"Month 1",task:"Issue Emirates ID if new visa",law:"ICP — within 30 days",done:false},
            {step:"Month 1",task:"Add to company health insurance",law:"UAE law requirement",done:false},
          ].map((item,i)=><div key={i} style={{display:"flex",gap:10,padding:"8px 0",borderBottom:i<9?`1px solid ${C.border}10`:undefined,alignItems:"flex-start"}}>
            <div style={{width:20,height:20,borderRadius:5,background:item.done?C.greenD:C.bg,border:`1.5px solid ${item.done?C.green:C.border}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,flexShrink:0,marginTop:1}}>{item.done?"✓":""}</div>
            <div style={{flex:1}}>
              <div style={{fontSize:11,fontWeight:item.done?700:400,color:item.done?C.green:C.text}}>{item.task}</div>
              <div style={{fontSize:9,color:C.dim}}>{item.step} · {item.law}</div>
            </div>
          </div>)}
        </Card>
        <Card className="fu" style={{animationDelay:".1s"}}>
          <div style={{fontFamily:"'Syne',sans-serif",fontSize:14,fontWeight:700,color:C.red,marginBottom:14}}>🚪 Employee Offboarding</div>
          {[
            {step:"Notice period",task:"Issue formal termination letter",law:"Decree Law 33 — Article 43"},
            {step:"Last day",task:"Process final salary + EOS gratuity",law:"Within 14 days of last day"},
            {step:"Last day",task:"Cancel work permit on MOHRE",law:"Mandatory cancellation"},
            {step:"Last day",task:"Cancel residency visa via ICP",law:"Within 30 days"},
            {step:"Last day",task:"Collect company assets + access cards",law:"Internal process"},
            {step:"Day 14",task:"Submit WPS final salary record",law:"WPS 2.0 compliance"},
            {step:"Day 14",task:"Issue experience certificate",law:"Employee right — Article 50"},
            {step:"Day 30",task:"Cancel Emirates ID registration",law:"ICP requirement"},
            {step:"Day 30",task:"Update NAFIS Emirati records",law:"If UAE national"},
            {step:"Day 30",task:"Archive all employee documents",law:"MOHRE — 5 year retention"},
          ].map((item,i)=><div key={i} style={{display:"flex",gap:10,padding:"8px 0",borderBottom:i<9?`1px solid ${C.border}10`:undefined,alignItems:"flex-start"}}>
            <div style={{width:20,height:20,borderRadius:5,background:C.bg,border:`1.5px solid ${C.border}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,flexShrink:0,marginTop:1,color:C.dim}}>○</div>
            <div style={{flex:1}}>
              <div style={{fontSize:11,color:C.text}}>{item.task}</div>
              <div style={{fontSize:9,color:C.dim}}>{item.step} · {item.law}</div>
            </div>
          </div>)}
        </Card>
      </div>
    </div>}

    {/* Leave Modal */}
    {leaveModal&&<Modal title={`Record Leave — ${leaveModal.name}`} onClose={()=>setLeaveModal(null)}>
      <div style={{display:"flex",flexDirection:"column",gap:13}}>
        <Sel label="Leave Type" value={leaveForm.type} onChange={v=>setLeaveForm(p=>({...p,type:v}))}
          options={[{v:"annual",l:"Annual Leave"},{v:"sick",l:"Sick Leave"},{v:"unpaid",l:"Unpaid Leave"},{v:"hajj",l:"Hajj Leave (once)"}]}/>
        <Inp label="Number of Days" value={String(leaveForm.days)} onChange={v=>setLeaveForm(p=>({...p,days:Number(v)||1}))} type="number"/>
        <Inp label="Reason / Notes" value={leaveForm.reason} onChange={v=>setLeaveForm(p=>({...p,reason:v}))} placeholder="Annual holiday, medical appointment..."/>
        <div style={{padding:"10px 14px",background:C.bg,borderRadius:9,fontSize:11,color:C.dim}}>
          {leaveForm.type==="annual"&&`Remaining after this: ${Math.max(0,(leaveModal.annualLeave||30)-(leaveModal.annualUsed||0)-leaveForm.days)} days`}
          {leaveForm.type==="sick"&&`Remaining after this: ${Math.max(0,(leaveModal.sickLeave||60)-(leaveModal.sickUsed||0)-leaveForm.days)} days`}
        </div>
        <div style={{display:"flex",gap:9,justifyContent:"flex-end"}}>
          <Btn v="ghost" onClick={()=>setLeaveModal(null)}>{t.cancel}</Btn>
          <Btn v="green" onClick={()=>updateLeave(leaveModal,leaveForm.type,leaveForm.days)}>Record Leave</Btn>
        </div>
      </div>
    </Modal>}
  </div>;
}

// ═══════════════════════════════════════════════════════════
// SETTINGS — WORKFLOW CONFIGURATION
// ═══════════════════════════════════════════════════════════
function SettingsPage({t,user,setUser,addToast,doLogout,lang,setLang}){
  const [f,setF]=useState({name:user?.name||"",biz:user?.biz||"",bizType:user?.bizType||"Retail Store",phone:user?.phone||""});
  const [settingsTab,setSettingsTab]=useState("account");
  const [workflows,setWorkflows]=useState(()=>{
    try{return JSON.parse(localStorage.getItem("jadwal_workflows")||"null")||{
      blockScheduleOnMissingDocs:true,
      blockScheduleOnExpiredPermit:true,
      autoHRChecklistOnNewEmp:true,
      warnProbationExpiry:true,
      autoWhatsAppOnPublish:true,
      requireContractBeforeSchedule:false,
      hrApprovalForSchedule:false,
      notifyHROnNewEmp:true,
      autoEOSAlert:true,
      leaveAutoDeduct:true,
    };}catch{return {};}
  });
  const sf=k=>v=>setF(p=>({...p,[k]:v}));
  const saveAccount=()=>{setUser({...user,...f});addToast(lang==="en"?"Settings saved ✓":"تم الحفظ ✓");};
  const toggleWF=k=>{
    const updated={...workflows,[k]:!workflows[k]};
    setWorkflows(updated);
    localStorage.setItem("jadwal_workflows",JSON.stringify(updated));
    addToast("Workflow setting updated ✓");
  };

  const STABS=[
    {id:"account",icon:"👤",label:"Account"},
    {id:"workflow",icon:"⚙️",label:"Workflow Rules"},
    {id:"hr_flow",icon:"📋",label:"HR Automation Flow"},
    {id:"roles",icon:"🔑",label:"Roles & Permissions"},
    {id:"features",icon:"✅",label:"Features"},
  ];

  const WFSwitch=({k,label,desc,color=C.gold,group})=>(
    <div style={{display:"flex",gap:14,padding:"12px 0",borderBottom:`1px solid ${C.border}10`,alignItems:"flex-start"}}>
      <div style={{flex:1}}>
        {group&&<div style={{fontSize:9,color:color,fontWeight:700,letterSpacing:1,textTransform:"uppercase",marginBottom:3}}>{group}</div>}
        <div style={{fontWeight:600,fontSize:13,color:C.text}}>{label}</div>
        <div style={{fontSize:11,color:C.dim,marginTop:2,lineHeight:1.6}}>{desc}</div>
      </div>
      <button onClick={()=>toggleWF(k)} style={{
        width:46,height:26,borderRadius:13,border:"none",cursor:"pointer",
        background:workflows[k]?color:C.border,transition:"all .2s",
        position:"relative",flexShrink:0,marginTop:2
      }}>
        <div style={{
          width:20,height:20,borderRadius:"50%",background:"#fff",
          position:"absolute",top:3,transition:"left .2s",
          left:workflows[k]?"23px":"3px",boxShadow:"0 1px 4px rgba(0,0,0,.3)"
        }}/>
      </button>
    </div>
  );

  const FEATURES=[
    {icon:"🤖",f:"AI Schedule Generator",s:"Claude AI · UAE Labor Law"},
    {icon:"🌐",f:"Bilingual Arabic & English",s:"Full RTL Arabic support"},
    {icon:"🪪",f:"AI Emirates ID Scanner",s:"Camera + auto Emirati detection"},
    {icon:"🏛️",f:"MOHRE & NAFIS Tracking",s:"Live Emiratisation compliance"},
    {icon:"💰",f:"WPS 2.0 SIF Export",s:"UAE Wage Protection System"},
    {icon:"☀️",f:"Midday Break Law Auto-Block",s:"Jun–Sep 12:30–3PM outdoor ban"},
    {icon:"🛂",f:"Visa Expiry Detector",s:"90-day advance alerts"},
    {icon:"💬",f:"WhatsApp Auto-Notifications",s:"360Dialog Business API"},
    {icon:"📋",f:"HR & Visa Automation",s:"MOHRE ecosystem · Permits · Leave · EOS"},
    {icon:"🆕",f:"Probation Tracker",s:"6-month UAE law · Auto end-date"},
  ];

  return <div style={{display:"flex",flexDirection:"column",gap:16,maxWidth:600}}>
    {/* Settings tab bar */}
    <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
      {STABS.map(tb=><button key={tb.id} onClick={()=>setSettingsTab(tb.id)} style={{
        padding:"8px 14px",borderRadius:9,border:`1.5px solid ${settingsTab===tb.id?C.gold:C.border}`,
        background:settingsTab===tb.id?`${C.gold}14`:C.card,color:settingsTab===tb.id?C.gold:C.sub,
        fontWeight:settingsTab===tb.id?700:500,fontSize:11,cursor:"pointer",fontFamily:"inherit",
        display:"flex",alignItems:"center",gap:6,transition:"all .15s"
      }}><span>{tb.icon}</span>{tb.label}</button>)}
    </div>

    {/* ACCOUNT */}
    {settingsTab==="account"&&<Card glow className="fu">
      <div style={{fontFamily:"'Syne',sans-serif",fontSize:15,fontWeight:700,marginBottom:14}}>Account Details</div>
      <div style={{display:"flex",flexDirection:"column",gap:12}}>
        <Inp label={t.name} value={f.name} onChange={sf("name")}/>
        <Inp label={t.biz} value={f.biz} onChange={sf("biz")}/>
        <Sel label={t.bizType} value={f.bizType} onChange={sf("bizType")} options={BTYPES}/>
        <Inp label={t.phone} value={f.phone} onChange={sf("phone")} dir="ltr"/>
        <Btn onClick={saveAccount}>{t.save}</Btn>
      </div>
      <div style={{marginTop:16}}>
        <div style={{fontFamily:"'Syne',sans-serif",fontSize:13,fontWeight:700,marginBottom:10}}>🌐 Language</div>
        <div style={{display:"flex",gap:10}}>
          {["en","ar"].map(l=><button key={l} onClick={()=>setLang(l)} style={{flex:1,padding:"10px",borderRadius:10,border:`1.5px solid ${lang===l?C.gold:C.border}`,background:lang===l?`${C.gold}12`:C.bg,color:lang===l?C.gold:C.sub,fontWeight:700,fontSize:12,cursor:"pointer",fontFamily:"inherit"}}>{l==="en"?"🇬🇧 English":"🇦🇪 العربية"}</button>)}
        </div>
      </div>
    </Card>}

    {/* WORKFLOW RULES */}
    {settingsTab==="workflow"&&<Card className="fu">
      <div style={{fontFamily:"'Syne',sans-serif",fontSize:15,fontWeight:700,marginBottom:4}}>⚙️ Workflow Rules</div>
      <div style={{fontSize:11,color:C.dim,marginBottom:16}}>Control exactly how JADWAL connects scheduling, HR, and compliance — automatically.</div>

      <WFSwitch k="blockScheduleOnMissingDocs" color={C.orange}
        group="Schedule Alerts"
        label="Alert when employee has missing documents"
        desc="If an employee is missing passport, visa copy, or employment contract — the schedule still generates. A ⚠ HR badge appears on that employee in the schedule and an alert is sent to the HR manager simultaneously."/>
      <WFSwitch k="blockScheduleOnExpiredPermit" color={C.orange}
        label="Alert when work permit is expired"
        desc="Employees with expired MOHRE work permits are flagged ⚠ HR in the schedule. Schedule generates normally — HR is alerted at the same time to action the renewal."/>
      <WFSwitch k="requireContractBeforeSchedule" color={C.blue}
        label="Show badge if no signed contract on file"
        desc="New employees without a signed contract show a contract badge in the schedule. Schedule still generates — HR is notified to obtain the signature."/>
      <WFSwitch k="hrApprovalForSchedule" color={C.purple}
        label="Require HR approval before publishing schedule"
        desc="When enabled, the Publish button is locked until an HR manager marks the schedule as approved. For companies with a dedicated HR team."/>
      <WFSwitch k="autoHRChecklistOnNewEmp" color={C.green}
        group="HR Automation"
        label="Auto-start HR checklist when employee is added"
        desc="The moment a supervisor adds a new employee, JADWAL automatically creates their HR profile, document checklist, and onboarding task list in the HR Automation tab."/>
      <WFSwitch k="notifyHROnNewEmp" color={C.green}
        label="Send WhatsApp to HR manager when employee added"
        desc="When a supervisor adds a new employee, HR manager receives an automatic WhatsApp: name, role, join date, and the onboarding checklist link."/>
      <WFSwitch k="autoWhatsAppOnPublish" color={C.wa}
        group="WhatsApp"
        label="Auto-send WhatsApp when schedule is published"
        desc="Every employee receives their personalized schedule message automatically the moment the supervisor hits Publish."/>
      <WFSwitch k="warnProbationExpiry" color={C.purple}
        group="Compliance"
        label="Alert 30 days before probation ends"
        desc="Supervisor and HR both receive a reminder: employee's probation ends in 30 days. Decide: confirm employment or issue 14-day notice now."/>
      <WFSwitch k="autoEOSAlert" color={C.gold}
        label="Calculate and alert EOS gratuity at offboarding"
        desc="When an employee is deactivated, JADWAL automatically calculates their End of Service gratuity and alerts the manager with the exact amount due under UAE law."/>
      <WFSwitch k="leaveAutoDeduct" color={C.blue}
        label="Deduct leave from balance when recorded"
        desc="When leave is recorded in HR Automation, annual or sick leave balance updates automatically. Manager always sees real remaining entitlement."/>
    </Card>}

    {/* HR AUTOMATION FLOW */}
    {settingsTab==="hr_flow"&&<div className="fu" style={{display:"flex",flexDirection:"column",gap:12}}>
      <Card style={{background:`${C.blueD}`,border:`1.5px solid ${C.blue}40`}}>
        <div style={{fontFamily:"'Syne',sans-serif",fontSize:14,fontWeight:700,color:C.blue,marginBottom:8}}>How the HR Automation Flow Works</div>
        <div style={{fontSize:11,color:C.sub,lineHeight:1.8}}>This is the end-to-end journey from when a supervisor adds a new employee to when they appear on the first schedule — fully automated by JADWAL.</div>
      </Card>

      {[
        {n:"1",actor:"Supervisor",action:"Adds new employee in Employees tab",detail:"Name, role, nationality, phone, Emirates ID, join date, salary",auto:"JADWAL auto-creates HR profile with empty document checklist and onboarding tasks",color:C.blue,icon:"👤"},
        {n:"2",actor:"JADWAL Automatic",action:"HR checklist triggered instantly",detail:"Onboarding tasks created: collect docs, register contract on MOHRE, book medical, activate WPS",auto:"WhatsApp sent to HR manager: 'New employee added — onboarding required'",color:C.gold,icon:"⚙️"},
        {n:"3",actor:"HR Manager",action:"Goes to HR Automation → Documents tab",detail:"Uploads or marks each document: Passport, Emirates ID, Visa, Contract, Medical",auto:"Document completion score updates live. Status changes from ⚠ Pending to ✓ Ready",color:C.purple,icon:"📋"},
        {n:"4",actor:"HR Manager",action:"Goes to HR Automation → Work Permits tab",detail:"Confirms MOHRE work permit applied and number recorded",auto:"Employee permit status turns green. Onboarding checklist item ticked off automatically",color:C.green,icon:"🏛️"},
        {n:"5",actor:"JADWAL Automatic",action:"HR alerts sent alongside schedule",detail:"Schedule always generates — HR issues never stop the schedule",auto:"⚠ HR badge appears on employees with issues. Supervisor and HR both see the alert at the same time. Work continues uninterrupted.",color:C.orange,icon:"⚡"},
        {n:"6",actor:"Supervisor",action:"Generates AI schedule",detail:"Employee now appears in the schedule without any ⚠ HR warning badge",auto:"Schedule published → employee receives personalized WhatsApp with their shifts",color:C.gold,icon:"🗓"},
        {n:"7",actor:"JADWAL Automatic",action:"Ongoing monitoring",detail:"Visa expiry, permit renewal, probation end, leave balance — all tracked continuously",auto:"Alerts sent automatically at 90, 60, 30 days before any deadline",color:C.blue,icon:"🔔"},
      ].map((step,i)=><div key={i} className="fu" style={{animationDelay:`${i*.05}s`,display:"flex",gap:12}}>
        <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:0}}>
          <div style={{width:36,height:36,borderRadius:"50%",background:`${step.color}22`,border:`2px solid ${step.color}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0}}>{step.icon}</div>
          {i<6&&<div style={{width:2,height:24,background:`${step.color}40`,margin:"2px 0"}}/>}
        </div>
        <div style={{flex:1,background:C.card,borderRadius:12,padding:"12px 14px",border:`1px solid ${step.color}22`,marginBottom:i<6?0:0}}>
          <div style={{display:"flex",gap:8,alignItems:"center",marginBottom:5}}>
            <Bdg color={step.color}>Step {step.n}</Bdg>
            <span style={{fontSize:10,color:step.color,fontWeight:700}}>{step.actor}</span>
          </div>
          <div style={{fontWeight:700,fontSize:13,color:C.text,marginBottom:3}}>{step.action}</div>
          <div style={{fontSize:11,color:C.sub,marginBottom:6}}>{step.detail}</div>
          <div style={{fontSize:10,color:step.color,padding:"5px 10px",background:`${step.color}10`,borderRadius:7,border:`1px solid ${step.color}25`}}>
            ⚡ Auto: {step.auto}
          </div>
        </div>
      </div>)}
    </div>}

    {/* ROLES & PERMISSIONS */}
    {settingsTab==="roles"&&<div className="fu" style={{display:"flex",flexDirection:"column",gap:12}}>
      <Card>
        <div style={{fontFamily:"'Syne',sans-serif",fontSize:14,fontWeight:700,marginBottom:14}}>🔑 Roles & Permissions</div>
        {[
          {role:"Owner / Admin",icon:"👑",color:C.gold,perms:["Full access to all features","Add/remove employees","Configure workflow settings","View financial reports","Manage subscriptions","Approve HR requests"]},
          {role:"Supervisor / Manager",icon:"👔",color:C.blue,perms:["Add employees (HR workflow auto-starts)","Generate and publish schedules","Record leave requests","View HR document status","Cannot configure workflow settings","Cannot access billing"]},
          {role:"HR Manager",icon:"📋",color:C.purple,perms:["Full HR Automation tab access","Upload and manage documents","Process work permit renewals","Approve onboarding checklists","Record leave and EOS","Cannot publish schedules"]},
          {role:"Employee (App)",icon:"👤",color:C.green,perms:["View own schedule on employee app","Request leave via app","View own documents status","Receive WhatsApp notifications","Cannot see other staff data","Cannot access management features"]},
        ].map((r,i)=><div key={i} className="fu" style={{animationDelay:`${i*.07}s`,background:C.bg,borderRadius:13,padding:"14px 16px",marginBottom:10,border:`1px solid ${r.color}25`}}>
          <div style={{display:"flex",gap:10,alignItems:"center",marginBottom:10}}>
            <div style={{width:36,height:36,borderRadius:10,background:`${r.color}18`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18}}>{r.icon}</div>
            <div style={{fontWeight:700,fontSize:14,color:r.color}}>{r.role}</div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:5}}>
            {r.perms.map((p,j)=><div key={j} style={{fontSize:10,color:p.startsWith("Cannot")?C.dim:C.sub,display:"flex",gap:5,alignItems:"flex-start"}}>
              <span style={{color:p.startsWith("Cannot")?C.red:C.green,flexShrink:0}}>{p.startsWith("Cannot")?"✗":"✓"}</span>{p}
            </div>)}
          </div>
        </div>)}
        <div style={{padding:"10px 14px",background:C.bg,borderRadius:9,fontSize:11,color:C.dim,marginTop:4}}>Role-based access control will be fully enforced in JADWAL Production v2.0 · Currently all users have Owner access in MVP</div>
      </Card>
    </div>}

    {/* FEATURES */}
    {settingsTab==="features"&&<div className="fu" style={{display:"flex",flexDirection:"column",gap:10}}>
      <Card>
        <div style={{fontFamily:"'Syne',sans-serif",fontSize:14,fontWeight:700,marginBottom:14}}>✅ Active Platform Features</div>
        {FEATURES.map((f2,i)=><div key={i} style={{display:"flex",gap:10,padding:"9px 0",borderBottom:i<FEATURES.length-1?`1px solid ${C.border}10`:undefined,alignItems:"center"}}>
          <span style={{fontSize:16}}>{f2.icon}</span>
          <div style={{flex:1}}><div style={{fontSize:12,fontWeight:600}}>{f2.f}</div><div style={{fontSize:10,color:C.dim}}>{f2.s}</div></div>
          <Bdg color={C.green}>Active</Bdg>
        </div>)}
      </Card>
      <Card style={{animationDelay:".1s"}}>
        <div style={{fontFamily:"'Syne',sans-serif",fontSize:14,fontWeight:700,marginBottom:12}}>📱 Subscription</div>
        <div style={{padding:"12px 14px",background:`${C.gold}08`,border:`1px solid ${C.goldD}`,borderRadius:10,marginBottom:12}}>
          <div style={{fontWeight:700,fontSize:13,color:C.gold}}>🎁 Free Trial Active — All Features Unlocked</div>
          <div style={{fontSize:11,color:C.dim,marginTop:3}}>30 days · No credit card required</div>
        </div>
        <Btn v="outline" full>Upgrade to Starter — AED 299/mo</Btn>
      </Card>
    </div>}

    <Btn v="red" full onClick={()=>{if(window.confirm("Sign out?"))doLogout();}} style={{marginTop:4}}>{t.signOut}</Btn>
  </div>;
}
