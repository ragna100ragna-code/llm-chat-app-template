# JADWAL — Deploy to Live in 15 Minutes
## Thomas Tamrat Goshu · in5 Tech · Dubai Internet City

---

## STEP 1 — Create GitHub Account (2 min)
Go to: https://github.com/signup
- Username: jadwal-ae
- Email: thomas.kiya@yahoo.com
- Create account

---

## STEP 2 — Upload This Folder to GitHub (5 min)

1. Go to: https://github.com/new
2. Repository name: **jadwal-platform**
3. Set to **Public**
4. Click "Create repository"
5. On the next page click **"uploading an existing file"**
6. Drag the entire contents of this folder into the upload area
7. Click "Commit changes"

---

## STEP 3 — Deploy on Vercel (3 min)

1. Go to: https://vercel.com/signup
2. Click **"Continue with GitHub"**
3. Click **"Add New Project"**
4. Select **jadwal-platform** from your repos
5. Framework: **Vite** (auto-detected)
6. Click **Deploy**

Vercel gives you a live URL instantly:
→ **https://jadwal-platform.vercel.app**

---

## STEP 4 — Connect Your Domain (optional, later)

Once you buy jadwal.ae:
1. Vercel → Settings → Domains
2. Add: jadwal.ae
3. Follow DNS instructions

---

## YOUR LIVE DEMO CREDENTIALS

URL: https://jadwal-platform.vercel.app
Email: demo@jadwal.ae
Password: demo123

Share this link with every potential client and investor.

---

## FINDING FIRST 5 PAYING CLIENTS THIS WEEK

### Target 1: Dubai Mall / Mall of Emirates retail stores
Walk in. Ask to speak to the store manager or operations manager.
Say: "I have a free tool that builds your staff schedule in 10 seconds and sends WhatsApp to every employee automatically. Can I show you on my phone? Takes 2 minutes."

### Target 2: Restaurants in Dubai Marina / JBR
Go at 3PM (quietest time). Ask for the restaurant manager.
Same pitch. Show the demo. Leave your WhatsApp.

### Target 3: Hotels — F&B department managers
Go to the HR or F&B manager. Mention Emiratisation fines.
Say: "Are you tracking your Emiratisation quota? JADWAL does it automatically."

### Target 4: Clinics in JLT / DIFC
Medical clinics with 5+ staff are perfect. Shift work, compliance-heavy.

### Target 5: in5 community itself
The other startups at in5 have staff. Ask the in5 team to introduce you.

---

## YOUR PITCH IN ONE SENTENCE

"I can build your staff schedule in 10 seconds, send every employee a WhatsApp automatically, and track your Emiratisation quota — all for AED 299 a month."

Then show the demo on your phone.

---

## YOUR CONTACT FOR CLIENTS

WhatsApp: +971 55 460 8810
Email: thomas.kiya@yahoo.com
Demo: jadwal-platform.vercel.app

© 2026 JADWAL Technologies · in5 Tech · Dubai Internet City
